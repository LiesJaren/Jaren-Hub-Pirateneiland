/**
 * Zet een bestaande FamiliePlanner-back-up één keer in de lokale database.
 *
 * Gebruik:
 *   npm run migrate:planner -- /pad/naar/familieplanner-backup.json
 *
 * Het script is veilig om opnieuw te draaien: als er al een standaardplanner
 * bestaat, verandert het niets.
 */
import { randomUUID } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { db, getSetting, setSetting } from '../server/db';

type Backup = {
  format?: unknown;
  version?: unknown;
  data?: unknown;
};

type PlannerData = Record<string, unknown> & {
  members: unknown[];
  events: unknown[];
  groceries: unknown[];
  rewards: unknown[];
  customIcons: unknown[];
  customCategories: unknown[];
  customRoutines: unknown[];
  preferences?: unknown;
};

function fail(message: string): never {
  console.error(`\n✗ ${message}\n`);
  process.exit(1);
}

function isPlannerData(value: unknown): value is PlannerData {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const data = value as Record<string, unknown>;
  const arrays = [
    'members',
    'events',
    'groceries',
    'rewards',
    'customIcons',
    'customCategories',
    'customRoutines',
  ];
  return arrays.every((key) => Array.isArray(data[key]));
}

const input = process.argv[2] ?? process.env.FAMILIE_PLANNER_BACKUP;
if (!input) {
  fail(
    'Geef het pad naar de back-up mee:\n' +
      '  npm run migrate:planner -- /pad/naar/familieplanner-backup.json',
  );
}

const path = resolve(input);
if (!existsSync(path)) fail(`Back-up niet gevonden: ${path}`);

let backup: Backup;
try {
  backup = JSON.parse(readFileSync(path, 'utf8')) as Backup;
} catch (error) {
  fail(`De back-up is geen geldige JSON: ${String(error)}`);
}

if (backup.format !== 'familieplanner-backup' || !isPlannerData(backup.data)) {
  fail('Dit is geen FamiliePlanner-back-up (formaat of gegevens kloppen niet).');
}

const existingDefault = getSetting('defaultPlannerId');
if (existingDefault) {
  const existing = db
    .prepare('SELECT revision FROM planner_data WHERE planner_id = ?')
    .get(existingDefault) as { revision: number } | undefined;
  if (existing) {
    console.log(`\nDe planner is al ingevoerd (${existingDefault}, revisie ${existing.revision}).`);
    console.log('Er is niets gewijzigd.\n');
    process.exit(0);
  }
}

const plannerId = process.env.PLANNER_ID ?? randomUUID();
if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(plannerId)) {
  fail('PLANNER_ID moet een geldige UUID zijn.');
}

const data = { ...backup.data, revision: 1 };
const now = new Date().toISOString();

db.prepare(
  `INSERT INTO planner_data (planner_id, data, revision, updated_at)
   VALUES (?, ?, ?, ?)
   ON CONFLICT(planner_id) DO UPDATE SET
     data = excluded.data,
     revision = excluded.revision,
     updated_at = excluded.updated_at`,
).run(plannerId, JSON.stringify(data), 1, now);

setSetting('defaultPlannerId', plannerId);

console.log('\n✓ FamiliePlanner ingevoerd in de lokale database.');
console.log(`  Planner-id: ${plannerId}`);
console.log(`  Revisie:    1`);
console.log(`  Afspraken:  ${(backup.data as PlannerData).events.length}`);
console.log(`  Gezinsleden:${(backup.data as PlannerData).members.length}`);
console.log(`\n  Open: http://localhost:3000/planner\n`);
