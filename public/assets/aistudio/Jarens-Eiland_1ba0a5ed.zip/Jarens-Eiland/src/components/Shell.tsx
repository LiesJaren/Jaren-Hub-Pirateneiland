import { useEffect } from 'react';
import { Home as HomeIcon, LockKeyhole } from 'lucide-react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { JAREN_SUPERHELD_AVATAR } from '../apps/planner/planner-src/data/jarenAvatar';
import { appForPath } from '../platform/apps';
import { usePlatform } from '../platform/PlatformContext';
import { OceanBackground } from './OceanBackground';
import { SpeechButton } from './SpeechButton';
import { StarBadge } from './StarBadge';

export function Shell() {
  const location = useLocation();
  const navigate = useNavigate();
  const { stars, theme, childName, refresh } = usePlatform();
  const isHome = location.pathname === '/';
  const isPlanner = location.pathname === '/planner';
  const currentApp = appForPath(location.pathname);

  useEffect(() => {
    void refresh();
  }, [location.pathname, refresh]);

  return (
    <div className={isHome ? 'app-shell hub-shell' : 'app-shell'} data-theme={theme}>
      {!isHome && !isPlanner && <OceanBackground />}

      {isHome && (
        <header className="hub-topbar">
          <div className="hub-topbar-main">
            <div className="hub-avatar" aria-hidden="true">
              <img
                src={JAREN_SUPERHELD_AVATAR}
                alt=""
                className="hub-avatar-image"
              />
            </div>
            <div className="hub-greeting">
              <p className="hub-eyebrow">Jouw eiland</p>
              <h1>Hoi {childName}!</h1>
              <p>Welkom terug. Kies een eiland.</p>
            </div>
            <SpeechButton
              text={`Hoi ${childName}! Welkom terug op jouw eiland. Kies een eiland.`}
              label="Lees de begroeting voor"
              className="hub-speech"
            />
          </div>

          <div className="hub-topbar-actions">
            <StarBadge stars={stars} />
            <button
              type="button"
              className="hub-parent-button"
              onClick={() => navigate('/ouder')}
              aria-label="Voor mama en papa"
            >
              <LockKeyhole size={18} strokeWidth={2.4} />
              <span>Papa &amp; mama</span>
            </button>
          </div>
        </header>
      )}

      {!isHome && !isPlanner && (
        <header className="topbar">
          <div className="topbar-left">
            <button
              type="button"
              className="home-button"
              onClick={() => navigate('/')}
              aria-label="Terug naar het eiland"
            >
              <HomeIcon size={21} strokeWidth={2.6} />
              <span>Eiland</span>
            </button>
            {currentApp && (
              <span className="topbar-app-title">
                <span aria-hidden="true">{currentApp.icon}</span> {currentApp.title}
              </span>
            )}
          </div>

          <div className="topbar-right">
            <StarBadge stars={stars} />
            <button
              type="button"
              className="parent-button"
              onClick={() => navigate('/ouder')}
              aria-label="Voor mama en papa"
            >
              <LockKeyhole size={18} strokeWidth={2.4} />
              <span>Papa &amp; mama</span>
            </button>
          </div>
        </header>
      )}

      <main
        className={isPlanner ? 'planner-page' : isHome ? 'page hub-page' : 'page'}
        key={location.pathname}
      >
        <Outlet />
      </main>
    </div>
  );
}
