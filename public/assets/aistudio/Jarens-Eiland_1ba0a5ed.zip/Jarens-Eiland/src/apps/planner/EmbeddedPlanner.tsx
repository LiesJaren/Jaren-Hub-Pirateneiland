import { useEffect, useState } from 'react';
import Planner from './planner-src/App';

const PLANNER_ID_KEY = 'fp_planner_id';
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function pickPlannerId(): Promise<void> {
  const fromUrl = new URLSearchParams(window.location.search).get('planner');
  if (fromUrl && UUID.test(fromUrl)) return;

  let localId: string | null = null;
  try {
    localId = localStorage.getItem(PLANNER_ID_KEY);
  } catch {
    return;
  }

  const response = await fetch('/api/planner/default', { cache: 'no-store' });
  if (!response.ok) return;
  const payload = (await response.json()) as { plannerId?: string | null };
  const defaultId = payload.plannerId;
  if (!defaultId || !UUID.test(defaultId)) return;

  if (!localId || !UUID.test(localId)) {
    localStorage.setItem(PLANNER_ID_KEY, defaultId);
    return;
  }

  if (localId === defaultId) return;

  // Een oude lokale planner zonder gegevens mag plaatsmaken voor de
  // planner die uit de back-up is ingevoerd. Heeft de lokale planner wél
  // gegevens, dan laten we die met rust.
  const meta = await fetch(
    `/api/planner?planner=${encodeURIComponent(localId)}&meta=1`,
    { cache: 'no-store' },
  );
  if (!meta.ok) return;
  const metaPayload = (await meta.json()) as { revision?: number };
  if (!Number.isInteger(metaPayload.revision) || metaPayload.revision === 0) {
    localStorage.setItem(PLANNER_ID_KEY, defaultId);
  }
}

export default function EmbeddedPlanner() {
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    void pickPlannerId()
      .catch((error: unknown) => {
        console.warn('Kon de standaardplanner niet bepalen:', error);
      })
      .finally(() => {
        if (!cancelled) setReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!ready) {
    return (
      <div className="planner-loading" role="status">
        <span className="planner-loading-dot" aria-hidden="true" />
        Jouw planbord wordt klaargezet...
      </div>
    );
  }

  return <Planner />;
}
