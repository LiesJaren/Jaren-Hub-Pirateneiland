# Jaren's Eiland

Eén startplek op Jarens laptop voor de familieplanner, een dagelijkse check-in,
gevoelens, en lezen/rekenen/schrijven. Alles in dezelfde rustige eilandstijl,
met grote knoppen en zo weinig tekst als mogelijk.

**Status:** de basis staat en de bestaande familieplanner is ingebed. De app
draait lokaal op de laptop; het ouderportaal is bereikbaar via het thuisnetwerk.
De installatie in het account `superjaren4` moet nog door een ouder worden
uitgevoerd (zie [Op Jarens laptop zetten](#op-jarens-laptop-zetten)).

---

## Wat zit erin?

| Onderdeel | Wat het doet |
|---|---|
| **Starteiland** (`/`) | Grote tegels naar elk onderdeel, met de sterrenteller. |
| **Familieplanner** (`/planner`) | De bestaande planner, ongewijzigd van opzet. Eigen agenda, kindermodus, ouderportaal, boodschappen en print. |
| **Dagcheck** (`/dagcheck`) | Drie korte vragen: gevoel, energie en waar Jaren naar uitkijkt. |
| **Gevoelens** (`/gevoelens`) | Kiezen hoe hij zich voelt, met uitleg en een tip. |
| **Leerwereld** (`/leren`) | Letterjacht, vissen tellen en letters typen. Volgt de doelen van VLL Kim kern 1 en zoWISo blok 1. |
| **Ouderportaal** (`/ouder`) | PIN-beveiligd: voortgang, laatste activiteit, naam/sfeer, PIN wijzigen en een back-up downloaden. |

De planner, dagcheck en leerspellen gebruiken **dezelfde sterrenteller**. De
balans staat bij het kind in de planner. Een ster uit een leerspel wordt dus
meteen bijgeschreven in de planner, en een ster die Jaren daar verdient of
inwisselt, ziet het eiland bij terugkomst.

---

## Snel starten (ontwikkelen)

### Vereisten

- Node 24 (vanwege `node:sqlite`). Op deze laptop staat Node lokaal in
  `~/.local/opt/node`; zet die eerst op je `PATH`:

  ```bash
  export PATH="$HOME/.local/opt/node/bin:$PATH"
  node -v
  ```

- Chrome of Chromium.
- Geen touchscreen nodig. Schrijven gebeurt met typen, letters bouwen en
  werkbladen op papier.

### Installeren en draaien

```bash
cd /home/liese/Documenten/Standaardproject
export PATH="$HOME/.local/opt/node/bin:$PATH"
npm install
npm run dev
```

- Eiland: <http://localhost:5173>
- API: <http://localhost:3001/api/health>
- Ouderportaal: <http://localhost:5173/ouder> (standaard-PIN `1234`)

`npm run dev` start de Express-server op poort 3001 en Vite op 5173. Vite
stuurt `/api` door naar de server.

### Controleren

```bash
npm run typecheck
npm run build
```

### Productie lokaal testen

```bash
npm run build
PORT=3100 npm start
```

Open <http://localhost:3100>. De productieversie bedient zowel de app als de
API vanuit Express. De echte installatie gebruikt poort 3000.

---

## Op Jarens laptop zetten

De app moet in het Linux-account van Jaren (`superjaren4`) draaien. Het
installatiescript doet alles in één keer. Het moet als root worden uitgevoerd,
omdat het bestanden in Jarens home zet en een systemd-gebruikersdienst maakt.

```bash
cd /home/liese/Documenten/Standaardproject
sudo bash scripts/install-jaren.sh
```

Wil je meteen de bestaande plannerback-up invoeren? Geef die dan mee:

```bash
sudo PLANNER_BACKUP=/home/liese/Documenten/FamiliePlanner-herstel/familieplanner-herstelbundel.json \
  bash scripts/install-jaren.sh
```

Het script:

1. kopieert de app naar `/home/superjaren4/jarens-eiland`;
2. installeert Node 24 lokaal in Jarens account (als dat nog niet werkt);
3. draait `npm ci` en `npm run build`;
4. maakt de systemd-dienst `jarens-eiland.service` op poort 3000;
5. zet een autostart klaar die Chrome in app-modus opent;
6. voert optioneel de plannerback-up in;
7. laat de dienst doorlopen ook als Jaren niet is ingelogd
   (`loginctl enable-linger`).

Na de installatie:

- uitloggen en opnieuw inloggen als Jaren opent het eiland automatisch;
- of start handmatig:

  ```bash
  /home/superjaren4/jarens-eiland/scripts/start-jarens-eiland.sh
  ```

- controleren:

  ```bash
  JR_UID="$(id -u superjaren4)"
  sudo -u superjaren4 env XDG_RUNTIME_DIR="/run/user/$JR_UID" \
    systemctl --user status jarens-eiland
  sudo -u superjaren4 env XDG_RUNTIME_DIR="/run/user/$JR_UID" \
    journalctl --user -u jarens-eiland -f
  sudo -u superjaren4 env XDG_RUNTIME_DIR="/run/user/$JR_UID" \
    systemctl --user restart jarens-eiland
  ```

> **Nog niet uitgevoerd.** De installatie in `superjaren4` is niet vanaf het
> account `liese` uitgevoerd. Vraag een ouder om het script te draaien en
> controleer daarna samen of Chrome opent en de plannergegevens zichtbaar zijn.

### Handmatig, zonder script

Als je liever zelf installeert:

```bash
# als superjaren4
mkdir -p ~/jarens-eiland
# kopieer de app hierheen (zonder node_modules en dist)
cd ~/jarens-eiland
export PATH="$HOME/.local/opt/node/bin:$PATH"
npm ci
npm run build
PORT=3000 npm start
```

Maak daarna zelf een systemd-gebruikersdienst en een autostart-bestand, of
gebruik het script als voorbeeld.

---

## Ouderportaal op je telefoon

De server luistert op het hele thuisnetwerk. Zoek het IP-adres van de laptop:

```bash
hostname -I
```

Open op je telefoon:

```text
http://<laptop-ip>:3000/ouder
```

De standaard-PIN is `1234`. **Verander die meteen** in het ouderportaal. De
waarschuwing bovenaan verdwijnt pas als je een eigen PIN hebt gekozen.

Als de pagina niet opent:

- zit de telefoon op hetzelfde wifi-netwerk?
- staat de laptopfirewall poort 3000 toe? Bijvoorbeeld:
  `sudo ufw allow 3000/tcp`
- draait de dienst? `sudo -u superjaren4 env XDG_RUNTIME_DIR="/run/user/$(id -u superjaren4)" systemctl --user status jarens-eiland`

Het ouderportaal is bedoeld voor het thuisnetwerk. Zet de server niet zomaar
open op het internet. Later kan een beveiligde tunnel of cloudsync worden
toegevoegd.

---

## De familieplanner

De bestaande planner is niet nagemaakt of herontworpen. De broncode staat in
`src/apps/planner/planner-src/` en wordt door `src/apps/planner/PlannerApp.tsx`
ingepakt. De planner houdt zijn eigen header, agenda, kindermodus,
ouderportaal, boodschappen en printknop.

- De platformbalk is op `/planner` verborgen; rechtsonder staat een zwevende
  **Eiland**-knop.
- De planner gebruikt nog steeds zijn eigen `fp_*`-localStorage-sleutels.
- Een link met `?planner=<uuid>` blijft werken. De planner zet die parameter
  zelf in de adresbalk.
- De planner synchroniseert nu met de lokale server in plaats van met de
  vroegere cloudopslag. De API heeft dezelfde vorm als vroeger:
  `GET/POST /api/planner?planner=<uuid>` en `GET ...&meta=1`.
- De plannergegevens staan in de tabel `planner_data` in dezelfde SQLite-
  database als de rest van het eiland.

### Plannerback-up invoeren

```bash
export PATH="$HOME/.local/opt/node/bin:$PATH"
npm run migrate:planner -- /pad/naar/familieplanner-backup.json
```

Het script:

- leest een bestand met `format: "familieplanner-backup"`;
- maakt een nieuwe planner-id of gebruikt `PLANNER_ID` als je die meegeeft;
- zet de gegevens met revisie 1 in de database;
- stelt de planner in als standaardplanner.

Het is veilig om opnieuw te draaien: als er al een standaardplanner is, wordt
niets overschreven. Op Jarens account moet je het script als Jaren draaien en
moet het back-upbestand voor hem leesbaar zijn. Het installatiescript regelt
dat met `PLANNER_BACKUP=...`.

---

## Sterren: één teller

De sterrenbalans van het kind in de planner is de enige teller.

- Een gebeurtenis met sterren (`POST /api/events`) schrijft de sterren bij het
  kind in de planner en verhoogt de plannerrevisie.
- De planner ziet de nieuwe revisie bij zijn volgende synchronisatie en neemt
  de nieuwe stand over.
- Verdient of wisselt Jaren sterren in de planner, dan leest `/api/summary` de
  nieuwe balans. Het eiland ververst bij terugkomst en bij focus.
- Het ouderportaal toont de balans en hoeveel sterren er via dagcheck en
  leerspellen zijn verdiend.
- Sterren die al vóór de koppeling in het eiland zijn verdiend, worden één keer
  bij de plannerbalans opgeteld.

De oude planner had al een eigen sterren- en beloningssysteem. Dat blijft
werken; het is nu dezelfde teller als het eiland.

---

## Gegevens en back-up

- Database: `~/.local/share/jarens-eiland/platform.db`
- Overschrijven met een andere map: `JAREN_DATA_DIR=/pad npm start`
- Tabellen: `events` (dagchecks, spellen, sterren), `settings` (naam, sfeer,
  PIN, standaardplanner) en `planner_data` (de volledige planner).
- De database gebruikt WAL-bestanden. Kopieer voor een handmatige back-up
  liever de hele map, of gebruik de knop in het ouderportaal.
- **Back-up downloaden** in het ouderportaal exporteert instellingen, alle
  gebeurtenissen én de plannergegevens als één JSON-bestand.
- Importeren van een eilandback-up is nog niet gebouwd. De plannerback-up
  invoeren kan wel met `npm run migrate:planner`.
- Testgegevens wissen: stop de dienst, verwijder
  `~/.local/share/jarens-eiland/platform.db` (en `-wal`/`-shm`) en start
  opnieuw. Dit wist alles, dus maak eerst een back-up.

---

## Een nieuwe app toevoegen

De app-registry ontdekt mappen automatisch. Een nieuwe app heeft twee bestanden
nodig:

```text
src/apps/mijnapp/
  manifest.tsx
  MijnApp.tsx
```

`manifest.tsx`:

```tsx
import type { AppManifest } from '../../platform/types';
import MijnApp from './MijnApp';

const manifest: AppManifest = {
  id: 'mijnapp',
  title: 'Mijn app',
  subtitle: 'Kort, met een icoon en grote knop.',
  icon: '🚀',
  color: '#38bdf8',
  route: '/mijnapp',
  order: 60,
  component: MijnApp,
};

export default manifest;
```

`MijnApp.tsx` gebruikt de gedeelde voortgang:

```tsx
import { usePlatform } from '../../platform/PlatformContext';

export default function MijnApp() {
  const { addEvent, stars } = usePlatform();

  async function klaar() {
    await addEvent({
      app: 'mijnapp',
      type: 'mijnapp.completed',
      stars: 1,
      payload: { wat: 'iets' },
    });
  }

  return (
    <div className="app-page">
      <h1>Mijn app</h1>
      <p>Je hebt {stars} sterren.</p>
      <button type="button" className="primary-button" onClick={() => void klaar()}>
        Klaar
      </button>
    </div>
  );
}
```

De tegel verschijnt automatisch op het starteiland. Zware apps kun je in hun
routecomponent lui laden met `lazy()`, zoals de planner doet. Nieuwe
gebeurtenissen verschijnen meteen in het ouderportaal.

---

## Technische opbouw

```text
server/
  index.ts        Express, statische productiebestanden, LAN-binding
  api.ts          gebeurtenissen, ouderportaal, back-up, spraak
  db.ts           SQLite, instellingen, tabellen
  plannerApi.ts   lokale planner-synchronisatie
  stars.ts        gedeelde sterrenbalans
  session.ts      ondertekende ouder-sessie
src/
  apps/           home, checkin, emotions, learning, planner, parent
  components/     Shell, topbar, achtergrond, mascotte, sterrenbadge
  platform/       app-registry, API-client, context, spraak, types
  styles.css      eilandstijl, thema's, planner-embed, print
scripts/
  install-jaren.sh
  start-jarens-eiland.sh
  migrate-planner-backup.ts
```

- Frontend: React 19, TypeScript, Vite, Tailwind 4, React Router.
- Server: Express 4, `node:sqlite` (Node 24).
- PWA: manifest en service worker via `vite-plugin-pwa`.
- Thema's: `mix`, `blocks` (blokken/Minecraft-gevoel) en `underwater`
  (onderwater/piraten). De sfeer staat in de instellingen en werkt als skin.
- Spraak: browserstem waar beschikbaar; anders de lokale
  `spd-say`-systeemstem via `/api/speak` (als die op de laptop staat).
- De planner gebruikt `html-to-image` en `jspdf` voor print/PDF. Die worden
  alleen geladen als de planner wordt geopend.

---

## Wat nog niet af is

- De installatie in `superjaren4` en de autostart zijn klaargezet maar nog niet
  op Jarens account uitgevoerd.
- De leerspellen zijn gebouwd en getest op de happy path, maar nog niet met
  Jaren zelf. Woordenschat en moeilijkheid kunnen na een echte sessie worden
  bijgesteld.
- Er zijn nog geen opgenomen stemfragmenten; de app gebruikt browser- of
  systeemspraak.
- Import van een volledige eilandback-up ontbreekt.
- Er is nog geen daglimiet op sterren. Een kind kan een spel of de dagcheck
  opnieuw doen en opnieuw sterren verdienen. Na de eerste echte test bekijken
  we of een dagdoel of limiet nodig is.
- Cloud/tunnel voor buitenshuis is bewust uitgesteld.
- Er zijn nog geen automatische tests.
- De PWA heeft PNG-iconen (192, 512 en maskable 512) en een SVG-icoon. De
  maskable versie is bedoeld voor Android-startschermen.
- De plannerlink bevat een geheim id. Deel hem alleen met het gezin; het
  ouderportaal heeft een PIN, de planner zelf werkt met de link als sleutel.

---

## Curriculumnotities

- **Lezen:** Veilig Leren Lezen, Kim-versie, kern 1. Letters: i, k, m, s, p,
  aa, r, e, v. Woorden: ik, kim, mis, sim, piraat, aap, raam, mes, vis.
- **Rekenen:** zoWISo, leerjaar 1, blok 1. Tellen en hoeveelheden tot 6,
  meer/minder/evenveel, vijfstructuur, splitsen tot 6, patronen, getallenlijn
  en ruimtelijke begrippen.
- **Schrijven:** geen vingertraceren (geen touchscreen). Wel letters typen,
  letters bouwen en werkbladen printen.
- De oefeningen zijn origineel. De methode bepaalt de volgorde en doelen, maar
  er is geen werkboekmateriaal overgenomen.
- De planner gebruikte al familiefoto's en eigen iconen; die zijn persoonlijk
  en niet van derden. Er zijn geen herkenbare personages uit series of games
  gebruikt.

---

## Licentie en herkomst

Dit is een privéproject voor het gezin. De plannerbron komt uit de bestaande
FamiliePlanner van de familie. Voeg alleen afbeeldingen en geluiden toe die je
zelf hebt gemaakt of die je mag gebruiken.
