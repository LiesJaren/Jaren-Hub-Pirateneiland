# Platform voor Jaren — plan van aanpak

**Status:** werkende basis gebouwd; planner ingebed en sterren gekoppeld.
Installatie in `superjaren4` en autostart zijn voorbereid maar nog niet uitgevoerd.
**Datum:** 23 oktober 2026
**Werkmap:** `/home/liese/Documenten/Standaardproject`

---

## 0. Gemaakte keuzes (23 oktober 2026)

| Onderwerp | Keuze |
|---|---|
| Toestel | Dell Latitude E5550, Linux Mint 22.2, geen touchscreen |
| Account | Jaren heeft een eigen Linux-account (`superjaren4`) |
| Planner | Bestaande planner blijft, wordt ingepakt |
| Voortgang | Eén gedeelde database op de laptop; ouder volgt via het thuisnetwerk |
| Lezen | Veilig Leren Lezen, Kim-versie, kern 1 |
| Rekenen | zoWISo, leerjaar 1, vanaf blok 1 |
| Profielen | Alleen Jaren |
| Naam | Jaren's Eiland |
| Sfeer | Mix: blokken/Minecraft + onderwater + piraten (originele art) |
| Opslag | Lokale Express-server + SQLite; ouder volgt via het thuisnetwerk |
| Sterren | Eén balans: de sterren van het kind in de planner |

### 0.1 Wat er nu staat

- Starteiland met grote tegels en één sterrenteller.
- Dagcheck met gevoel, energie en vooruitzicht.
- Gevoelensgids met uitleg en tips.
- Leerwereld met Letterjacht, Vissen tellen en Typ de letter.
- Ouderportaal met PIN, voortgang, activiteiten, naam/sfeer, PIN wijzigen en
  back-up (inclusief plannergegevens).
- Bestaande familieplanner ingebed op `/planner`, met eigen header en een
  zwevende Eiland-knop.
- Lokale planner-API (`/api/planner`) met SQLite en revisieconflicten.
- Plannerback-up ingevoerd in de ontwikkeldatabase (37 afspraken, 3 leden).
- Gedeelde sterrenbalans via het kind in de planner; leersterren worden
  bijgeschreven en plannersterren komen terug in het eiland.
- Thema's `mix`, `blocks` en `underwater`.
- Installatie- en autostartscripts voor `superjaren4` voorbereid.

Nog te doen: echte test met Jaren, installatie in zijn account, import van een
volledige eilandback-up, meer curriculum, en later cloud/tunnel.

---

## 1. Doel

Eén startplek op Jarens computer waar alle onderdelen samenkomen:

- de bestaande **familieplanner**;
- een **dagcheck-in**;
- een **emotie-tracker/gids**;
- een **leerwereld** met lezen, schrijven en rekenen, met games en beloningen;
- later: nieuwe apps, zonder dat alles opnieuw moet.

Jaren opent één app, ziet grote tegels en kan zelf naar een onderdeel. Elk onderdeel voelt als een eigen wereldje, maar hij kan altijd met één knop terug naar huis. Ouders beheren alles op één plek.

---

## 2. Ontwerpprincipes

1. **Kind eerst.** Jaren is 6 en leest nog niet vlot. Dus: pictogrammen, audio, grote knoppen, korte sessies en zo weinig mogelijk tekst.
2. **Ouders beheren, kind speelt.** Instellingen, inhoud en beloningen zitten achter een ouderpoort.
3. **Losse apps, één geheel.** Elke app heeft eigen schermen, eigen data en eigen tempo. De hub en gedeelde diensten zorgen dat het één platform voelt.
4. **Lokaal-eerst en privé.** Geen advertenties, geen tracking, geen externe links. Data staat op het toestel en is te exporteren.
5. **Uitbreidbaar.** Een nieuwe app toevoegen mag niet betekenen dat de rest moet worden aangepast.
6. **Niets stukmaken.** De bestaande planner blijft werken. We pakken hem eerst in en verfijnen later.

---

## 3. Architectuur

### 3.1 Drie lagen

```
┌─────────────────────────────────────────────────────┐
│  HUB / STARTSCHEM                                  │
│  avatar · sterren · "vandaag" · grote app-tegels     │
├─────────────────────────────────────────────────────┤
│  APPS                                               │
│  Planner │ Dagcheck │ Emoties │ Leerwereld │ ...    │
├─────────────────────────────────────────────────────┤
│  PLATFORMDIENSTEN                                   │
│  profiel · opslag · sterren · audio · ouderpoort ·  │
│  back-up · app-register                             │
└─────────────────────────────────────────────────────┘
```

- **Hub:** het startscherm. Groot, visueel, met de apps als tegels. Toont ook de stemming van de dag, de planning van vandaag en de sterrenteller.
- **Apps:** elk onderdeel is een aparte module met een eigen route, eigen schermen en een eigen dataruimte.
- **Platformdiensten:** gedeelde functies die elke app kan gebruiken: profiel, opslag, sterren/badges, spraak en geluid, ouderpoort, back-up en het app-register.

### 3.2 Eén schil, geen losse eilanden

Ik raad een **modulaire monoliet** aan: één repository, één build en één site, maar met apps die los van elkaar in een eigen map staan en lui worden geladen.

Waarom niet meteen losse sites in iframes of microservices?

- één samenhangende ervaring en één "huis"-knop;
- gedeelde sterren, profiel en ouderinstellingen;
- minder onderhoud en minder kans op versieverschillen;
- toch schone scheiding: een app kan later zonder veel werk los worden gebouwd of verhuisd.

Als een experimentele app ooit echt geïsoleerd moet draaien, ondersteunt het app-contract ook een **iframe-app**. Dat is de ontsnappingsroute, niet de standaard.

### 3.3 Technologie

Zoveel mogelijk dezelfde stack als de bestaande planner, zodat kennis en code hergebruikt worden:

| Onderdeel | Keuze | Waarom |
|---|---|---|
| Frontend | React 19 + TypeScript + Vite | Zelfde als de planner |
| Styling | Tailwind CSS 4 + eigen design tokens | Zelfde als de planner |
| Routing | React Router | Diepe links, browser-terug, app-routes |
| Opslag (nieuwe apps) | SQLite op de laptop, met browser-cache | Eén bron van waarheid, ook voor de ouder op het thuisnetwerk |
| Opslag (planner) | lokale SQLite via `/api/planner`, met `fp_*`-localStorage als cache/offline terugval | Dezelfde syncvorm als vroeger, maar zonder cloud |
| Offline | `vite-plugin-pwa` + service worker | De shell en games blijven laden zonder internet |
| Server/API | Express + SQLite, lokaal op de laptop | Planner-API en voortgang in één server |
| Tests | Vitest + Playwright | Logica en kritieke kindflows |
| Desktop later | Tauri | Echt app-venster, autostart, offline, updates |

**Repository-opbouw (huidig):**

```
Standaardproject/
├── src/
│   ├── apps/
│   │   ├── home/
│   │   ├── checkin/
│   │   ├── emotions/
│   │   ├── learning/
│   │   ├── planner/           # wrapper + planner-src/
│   │   └── parent/
│   ├── components/            # Shell, topbar, sterrenbadge, mascotte
│   ├── platform/              # app-register, API, context, spraak
│   └── styles.css
├── server/                    # Express-API (planner + platform)
├── scripts/                   # installatie, autostart, plannerimport
├── public/                    # icoon en PWA-assets
├── README.md
└── PLATFORM-PLAN.md
```

### 3.4 Het app-contract

Elke app krijgt een `manifest.tsx`. De shell ontdekt apps automatisch via
`import.meta.glob`, dus een nieuwe app toevoegen is: map maken + manifest +
klaar.

```tsx
// src/apps/leerwereld/manifest.tsx
import type { AppManifest } from '../../platform/types';
import LeerwereldApp from './LearningApp';

export default {
  id: 'leerwereld',
  title: 'Leerwereld',
  subtitle: 'Lezen, schrijven, rekenen',
  icon: '🚀',
  color: '#7c3aed',
  route: '/leren',
  order: 30,
  component: LeerwereldApp,
} satisfies AppManifest;
```

Zware apps (zoals de planner) laden hun eigenlijke component lui in de
routecomponent, zodat het starteiland snel blijft.


Afspraken:

- elke app krijgt een eigen opslagnaamruimte (`app:leerwereld:*`);
- een app praat alleen via de platform-API met profiel, sterren en instellingen;
- een app exporteert en importeert zijn eigen data voor de back-up;
- een app mag optioneel eigen ouderinstellingen aanbieden;
- de planner is de uitzondering: die houdt zijn bestaande `fp_*`-sleutels.

### 3.5 Schakelen tussen apps

- Een **permanente bovenbalk** met: huis-knop, app-naam, sterrenteller en ouder-slot.
- Grote **"Naar huis"**-knop, ook bereikbaar met `Esc` en de browser-terugknop.
- Elke app heeft een eigen kleur, mascotte en sfeer, zodat Jaren voelt dat hij ergens anders is.
- De hub onthoudt waar hij was, maar opent standaard rustig op het startscherm.
- Ouderpoort verbergt apps die (nog) niet klaar zijn of die Jaren even niet mag gebruiken.

---

## 4. De apps

### 4.1 Planner (bestaand)

De huidige planner is een volwaardige React-app van ongeveer 15.000 regels, met:

- React 19, TypeScript, Tailwind 4;
- vroeger een Express-server en Vercel KV; nu dezelfde API tegen lokale SQLite;
- localStorage-sleutels `fp_*` en een planner-ID in de link;
- spraak via Web Speech en `spd-say` op Linux;
- ouderportaal, kindermodus, print, boodschappen, sterren en beloningen.

Aanpak (uitgevoerd):

1. De map `FamiliePlanner/src` staat in `src/apps/planner/planner-src/`.
2. `src/apps/planner/PlannerApp.tsx` laadt de planner lui en toont de
   Eiland-knop; de shell verbergt op `/planner` zijn eigen bovenbalk.
3. De bestaande `fp_*`-gegevens en `?planner=`-link blijven werken.
4. De server implementeert `/api/planner` met dezelfde revisieconflicten.
5. De back-up is met `npm run migrate:planner` in SQLite gezet.
4. De Express-API's (`/api/planner`, `/api/generate-icon`) komen in de platformserver.
5. De planner krijgt een "Naar huis"-knop en een optionele koppeling met de sterren van het platform.
6. Later: gedeelde huisstijl en, als jullie dat willen, één sterrenportemonnee.

De eerste mijlpaal is dus: **dezelfde planner, maar met een nieuwe voordeur en op Jarens computer**.

### 4.2 Dagcheck-in

Een ritueel van ongeveer één minuut, 's ochtends en 's avonds.

- **Ochtend:** Hoe voel je je? Hoeveel energie heb je? Waar kijk je naar uit?
- **Avond:** Wat was het leukste? Wat was moeilijk? Waar ben je trots op?
- Antwoorden via pictogrammen en eventueel inspreken; typen is niet nodig.
- 's Ochtends kan de hub de check-in als eerste tegel tonen.
- Ouders zien een rustig overzicht, geen cijfers of diagnoses.
- De data komt in dezelfde "dagboek"-opslag als de emotie-app.

### 4.3 Emoties

Een gids om gevoelens te herkennen en ermee om te gaan.

- Gevoelskaarten: blij, boos, verdrietig, bang, moe, trots, zenuwachtig, ...
- Lichaamssignalen: "Waar voel je het?"
- Intensiteit: een beetje / veel / heel veel.
- Wat helpt: ademen, bewegen, knuffel, praten, even alleen.
- Begeleide oefeningen: ademhaling met een bel, 5-4-3-2-1-zintuigen, een verhaal.
- Ouders zien patronen en kunnen tips toevoegen.
- Duidelijk geen medisch hulpmiddel; bij zorgen verwijst de app naar een gesprek, niet naar een diagnose.

Dagcheck en emoties delen dezelfde dagboekopslag, maar blijven twee duidelijke ingangen.

### 4.4 Leerwereld

Dit is het grootste onderdeel. Ik zie het als **één leerwereld met een gamelaag**, niet als twee losse sites: de games zijn de manier waarop geoefend wordt, en de beloningen zitten eromheen.

**Lezen**

- letters en klanken herkennen;
- mkm-woorden (medeklinker-klinker-medeklinker) bouwen;
- rijmen;
- woord en beeld koppelen;
- korte zinnen begrijpen.

**Schrijven**

De laptop heeft geen touchscreen. Daarom leggen we de nadruk op oefeningen die met muis, trackpad en toetsenbord goed werken:

- letters bouwen uit streken en blokken;
- letters herkennen en de juiste letter kiezen;
- woorden overschrijven en typen;
- fijne motoriek en pengreep-oefeningen op papier, met de app als begeleiding;
- letter sporen met de muis kan als extraatje, maar is niet de kern;
- later eventueel een tekentablet voor echte schrijfoefeningen.

**Rekenen**

- tellen en hoeveelheden;
- getallen herkennen en vergelijken;
- splitsen;
- optellen en aftrekken tot 10 en later tot 20;
- vormen, patronen, meten, geld en tijd.

**Aansluiting bij school**

- **Lezen:** Veilig Leren Lezen, Kim-versie. Kern 1 bouwt verder op de letters i, k, m en s en voegt p, aa, r, e en v toe. We oefenen met woorden die met die letters gevormd kunnen worden, zoals ik, kim, mis, vis, kip, aap, raap, vaas en mes.
- **Rekenen:** zoWISo, leerjaar 1. Blok 1 gaat over tellen en hoeveelheden tot 6, meer/minder/evenveel, getallen herkennen en schrijven, de vijfstructuur, splitsen tot 6, patronen, de getallenlijn en begrippen als voor/achter/links/rechts.
- We nemen de **doelen en de volgorde** van de methode over, maar maken onze eigen oefeningen en teksten. We kopiëren geen werkboekpagina's of beschermd lesmateriaal. Ouders kunnen de letters of woorden van de week zelf invoeren.

**Spelvormen**

Quiz, memory, slepen en neerzetten, sporen, sorteren, verhaal met keuzes. Dezelfde spelvormen worden hergebruikt voor verschillende leerdoelen.

**Adaptief oefenen**

- elke oefening hoort bij een vaardigheid (bijv. `rekenen.splitsen.tot10`);
- drie keer goed → moeilijker; twee keer fout → makkelijker;
- herhaling via een eenvoudig Leitner-systeem;
- geen AI die ongecontroleerd oefeningen verzint; ouderlijk goedgekeurde content.

**Gamificatie**

- sterren, levels, badges, avatar-onderdelen en een dagdoel;
- geen levens, geen aftelklokken, geen ranglijsten, geen verlies;
- een reeks mag een dagje gemist worden zonder alles kwijt te zijn;
- echte beloningen worden, net als in de planner, door een ouder goedgekeurd.

**Ouders**

- voortgang per vaardigheid;
- tijd en fouten per sessie;
- moeilijkheid instellen;
- content aan- of uitzetten;
- schermtijd en een rustige stop.

### 4.5 Ouderpoort

Eén plek voor alle apps:

- app-volgorde en zichtbaarheid;
- moeilijkheid per vak;
- schermtijd;
- voortgang en dagboek;
- content beheren;
- back-up maken en terugzetten;
- ouder-PIN wijzigen.

### 4.6 Sfeer en mascotte

De sfeer is gekozen: een **originele mengeling** van een blokkerig onderwater-\neiland met een vriendelijke piraatsschildpad, **Kaptein Koraal**. Er zijn drie\nstanden in het ouderportaal: `mix` (onderwater + blokken), `blocks`\n(blokkenwereld) en `underwater` (onderwaterwereld). We gebruiken geen logo's,\npersonages of beelden van Minecraft, SpongeBob, Tip de Muis of Piet Piraat. Zo\nvoelt het vertrouwd voor Jaren, maar blijft het juridisch veilig en kunnen we\nhet later volledig aanpassen.\n\nDe sfeer zit in een aparte themalaag (`data-theme` op de app-shell). De apps\nzelf veranderen niet mee; alleen achtergrond, hero en accenten wisselen.

---

## 5. Gamificatie

Eén gedeelde "sterrenmotor" waar elke app op kan intekenen:

```ts
platform.rewards.add({
  app: 'leerwereld',
  amount: 2,
  reason: '3 woorden goed gelezen',
  skill: 'lezen.mkm',
});
```

Uitgangspunten:

- **Sterren** voor inzet en vooruitgang, niet alleen voor "goed".
- **Badges** voor mijlpalen (eerste woord, 10 keer gelezen, alle letters).
- **Avatar** die per level iets nieuws krijgt.
- **Dagdoel** in plaats van eindeloos spelen.
- **Ouderlijke beloning** voor grotere mijlpalen, zoals nu al in de planner.
- **Eén sterrenbalans.** De sterren van het kind in de planner zijn de teller. Een leerster wordt bijgeschreven in de planner; een plannerster komt terug in het eiland en het ouderportaal. De bestaande beloningslogica van de planner blijft ongewijzigd.

---

## 6. Data, back-up en synchronisatie

- **Eén bron van waarheid.** De laptop draait een kleine lokale server met SQLite. Alle apps schrijven hun voortgang daar naartoe. Zo is de voortgang automatisch hetzelfde in elke app.
- **Ouder op het thuisnetwerk.** Dezelfde server is bereikbaar vanaf de telefoon of tablet van de ouders op hetzelfde Wi-Fi-netwerk, achter de ouder-PIN. Zo kan je meekijken zonder cloud.
- **Lokaal-eerst.** De planner gebruikt nu dezelfde lokale SQLite-server, met zijn `fp_*`-localStorage als cache/offline terugval. Nieuwe apps gebruiken SQLite; de browser bewaart een cache voor offline gebruik.
- **Back-up.** Eén knop in het ouderportaal exporteert alle data als één bestand, met een versienummer. Elke app levert zijn eigen deel aan.
- **Import.** De bestaande plannerback-up (`familieplanner-herstelbundel.json`) blijft bruikbaar.
- **Buiten huis.** Willen jullie later vanop een ander netwerk meekijken, dan voegen we een beveiligde tunnel of cloud-sync toe. De data-opbouw blijft hetzelfde.
- **Migratie.** Als het platform op dezelfde origin draait (`localhost:3000`), blijven de `fp_*`-gegevens van de planner staan. Bij een nieuw domein zetten we de back-up terug. De `?planner=`-link blijft werken.

---

## 7. Op Jarens deel van de computer

### 7.1 Eigen account

Jaren heeft al een eigen Linux-account (`superjaren4`). Dat is zijn "deel" van de computer:

- eigen bureaublad, eigen browserprofiel, eigen bestanden;
- de ouder-accounts blijven beheerder;
- kiosk-achtige opstart alleen voor dat account;
- ouderlijk toezicht en schermtijd op OS-niveau waar mogelijk.

### 7.2 Installatie

**Aanbevolen: lokale server + PWA in app-modus**

- De lokale server draait als systemd-gebruikersdienst in Jarens account (of als systeemdienst, als de laptop ook zonder login bereikbaar moet zijn).
- Het platform opent in Chrome met `--app=http://localhost:3000 --start-fullscreen` via autostart.
- De ouder opent hetzelfde adres op de telefoon via het thuisnetwerk en logt in met de ouder-PIN.
- De service worker cachet de shell en de games, zodat de interface ook zonder internet laadt.
- Geen cloud, geen account voor Jaren, geen data die het huis verlaat.

**Later: Tauri-desktopapp**

- Zelfde webcode in een echt venster, met autostart, auto-update en native back-ups.
- Nodig als de app-modus te fragiel blijkt of als we meer OS-integratie willen.

**Optioneel: cloud**

- Alleen als jullie buiten het thuisnetwerk willen meekijken of meerdere huizen willen ondersteunen.
- Dezelfde code, met een beveiligde sync-laag.

De code blijft in alle gevallen dezelfde.

### 7.3 Ouderlijke uitgang

- Een ouder-PIN om de kindermodus te verlaten.
- Op OS-niveau: een beperkt account of kiosk-modus, niet alleen een knop in de app.
- Screen time: vriendelijke waarschuwing, dan een rustige stop. Geen abrupt zwart scherm.

---

## 8. Veiligheid, privacy en toegankelijkheid

- Geen advertenties, geen tracking, geen analytics van derden.
- Geen chat, geen externe links, geen openbare inhoud.
- Data lokaal; back-up is expliciet.
- De lokale server staat alleen open op het thuisnetwerk en achter de ouder-PIN.
- Ouderpoort met PIN; geen wachtwoord voor Jaren nodig.
- Foto's en avatars: lokaal houden waar kan.
- Grote klikdoelen (minstens 64 px), hoog contrast, audio, respect voor "minder beweging".
- Lettertype-optie voor dyslexie; rustige achtergronden.
- Nederlandse interface, eenvoudige taal, Vlaamse uitspraak waar mogelijk.
- De emotie-app is een gids, geen diagnose.
- Content wordt door ouders goedgekeurd; AI mag helpen bij het maken, niet ongezien publiceren.

---

## 9. Roadmap

| Fase | Wat | Status |
|---|---|---|
| **0. Fundering** | repo, shell, app-register, design tokens, lokale server + SQLite, PWA, ouderpoort, back-up | **Gedaan** |
| **1. Planner erin** | planner inpakken, lokale `/api/planner`, back-up migreren, Eiland-knop, gedeelde sterren | **Gedaan** in de ontwikkelomgeving; installatie op Jarens account nog niet |
| **2. Dagcheck + emoties** | dagboekopslag, beide apps, ouderoverzicht, hub-koppeling | **Gedaan** |
| **3. Leerwereld MVP** | 3 spellen (lezen, schrijven, rekenen), sterren, ouder dashboard | **Gedaan** op de happy path; echte test met Jaren volgt |
| **4. Uitbreiden** | meer content, adaptief systeem, badges/avatar, extra spellen, polish | **Volgende** |
| **5. Sync en desktop** | optionele tunnel/cloud, Tauri/kiosk, documentatie, CI | **Later** |

De eerste werkende versie staat. De komende stap is samen met Jaren spelen,
bijstellen en daarna de installatie in zijn account afronden.

---

## 10. Wat al beslist is

- Dell Latitude E5550 met Linux Mint 22.2, geen touchscreen.
- Jaren heeft een eigen account (`superjaren4`).
- De bestaande planner blijft zoals hij is.
- Naam: **Jaren's Eiland**.
- Sfeer: mix van blokken/Minecraft, onderwater en piraten, met originele art.
- Eén gedeelde sterrenbalans, lokaal op de laptop, met ouderoverzicht via het
  thuisnetwerk.
- Alleen Jaren.
- Lezen: VLL Kim, kern 1. Rekenen: zoWISo, leerjaar 1, blok 1.
- Schrijven zonder touchscreen: typen, letters bouwen en printen.
- Ouder-PIN, standaard `1234`, verplicht aan te passen in het ouderportaal.

## 11. Nog te beslissen

1. **Ouder-toegang:** is meekijken via het thuisnetwerk voldoende, of moet het
   later ook buiten huis werken (beveiligde tunnel/cloud)?
2. **Autostart:** opent het eiland automatisch bij inloggen (nu voorbereid), of
   start Jaren het liever zelf via de menu-snelkoppeling?
3. **Kiosk:** gewoon fullscreen met een sluitbare Chrome-app, of een strengere
   kioskmodus?
4. **Inhoud:** welke extra letters/woorden en rekenoefeningen wil je na de
   eerste echte sessie met Jaren zien?
5. **Sterrenlimiet:** blijven herhalingen sterren opleveren, of komt er een
   dagdoel/limiet per spel en voor de dagcheck?

---

## 12. Volgende stap

1. Samen met Jaren de drie leerspellen en de dagcheck testen.
2. De installatie in `superjaren4` uitvoeren met
   `sudo bash scripts/install-jaren.sh` (eventueel met `PLANNER_BACKUP=...`).
3. De standaard-PIN wijzigen en het ouderportaal op de telefoon testen.
4. Kijken of de plannergegevens en sterren kloppen na een echte sessie.
5. Daarna content, badges/avatar en eventueel import/cloud toevoegen.

Daarna kunnen we per fase verder, telkens met iets dat meteen bruikbaar is.
