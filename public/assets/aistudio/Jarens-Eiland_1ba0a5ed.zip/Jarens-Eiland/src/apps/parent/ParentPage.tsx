import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  ArrowLeft,
  Check,
  Download,
  Gamepad2,
  KeyRound,
  LogOut,
  RefreshCw,
  ShieldCheck,
  Star,
  Sun,
} from 'lucide-react';
import { PageHeader } from '../../components/PageHeader';
import {
  changeParentPin,
  getParentSession,
  getParentSummary,
  parentLogin,
  parentLogout,
  saveParentSettings,
} from '../../platform/api';
import { formatWhen } from '../../platform/format';
import { moodById } from '../../platform/moods';
import { usePlatform } from '../../platform/PlatformContext';
import type { ParentSummary, PlatformEvent } from '../../platform/types';

const appNames: Record<string, string> = {
  planner: 'Planbord',
  checkin: 'Dagcheck',
  emotions: 'Gevoelens',
  learning: 'Leerwereld',
};

function eventTitle(event: PlatformEvent): string {
  if (event.type === 'checkin') {
    const mood = moodById(event.payload.mood);
    return `Dagcheck: ${mood?.label.toLowerCase() ?? 'ingevuld'}`;
  }
  if (event.type === 'game.completed') {
    const game = String(event.payload.game ?? '');
    if (game === 'letterjacht') return 'Letterjacht gespeeld';
    if (game === 'vissentellen') return 'Vissen geteld';
    if (game === 'lettertypen') return 'Letters getypt';
    return 'Spelletje gespeeld';
  }
  if (event.type === 'emotion') {
    const feeling = moodById(event.payload.feeling);
    const intensity = Number(event.payload.intensity);
    const intensityLabel =
      intensity === 3 ? 'heel veel' : intensity === 2 ? 'veel' : intensity === 1 ? 'een beetje' : '';
    return `Gevoel gedeeld: ${feeling?.label.toLowerCase() ?? 'onbekend'}${
      intensityLabel ? ` (${intensityLabel})` : ''
    }`;
  }
  return `${appNames[event.app] ?? event.app} · ${event.type}`;
}

function eventEmoji(event: PlatformEvent): string {
  if (event.type === 'checkin') return moodById(event.payload.mood)?.emoji ?? '🌤️';
  if (event.type === 'game.completed') return '🎮';
  if (event.type === 'emotion') return moodById(event.payload.feeling)?.emoji ?? '💛';
  return '✨';
}

export default function ParentPage() {
  const { refresh: refreshPlatform } = usePlatform();
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [summary, setSummary] = useState<ParentSummary | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadSummary = useCallback(async () => {
    try {
      const next = await getParentSummary();
      setSummary(next);
      setError(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Kon de gegevens niet laden.');
    }
  }, []);

  useEffect(() => {
    void getParentSession()
      .then((session) => {
        setAuthenticated(session.authenticated);
        if (session.authenticated) void loadSummary();
      })
      .catch(() => setAuthenticated(false));
  }, [loadSummary]);

  if (authenticated === null) {
    return (
      <div className="app-page">
        <div className="panel">Even kijken...</div>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <ParentLogin
        onSuccess={() => {
          setAuthenticated(true);
          void loadSummary();
        }}
      />
    );
  }

  return (
    <ParentDashboard
      summary={summary}
      error={error}
      onRefresh={async () => {
        await loadSummary();
        await refreshPlatform();
      }}
      onLogout={async () => {
        await parentLogout();
        setAuthenticated(false);
        setSummary(null);
      }}
    />
  );
}

function ParentLogin({ onSuccess }: { onSuccess: () => void }) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!pin) return;
    setLoading(true);
    setError(null);
    try {
      await parentLogin(pin);
      onSuccess();
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'Die PIN klopt niet.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="app-page parent-page">
      <form className="panel parent-login" onSubmit={(event) => void submit(event)}>
        <div className="parent-lock" aria-hidden="true">
          🔐
        </div>
        <p className="eyebrow">Ouderportaal</p>
        <h1>Voor mama &amp; papa</h1>
        <p>Voer de PIN in om de voortgang en instellingen te bekijken.</p>

        <label htmlFor="parent-pin" className="field-label">
          PIN
        </label>
        <input
          id="parent-pin"
          className="pin-input"
          type="password"
          value={pin}
          onChange={(event) => setPin(event.target.value.replace(/\D/g, '').slice(0, 8))}
          inputMode="numeric"
          pattern="[0-9]*"
          autoComplete="off"
          maxLength={8}
          autoFocus
          aria-describedby={error ? 'pin-error' : undefined}
        />
        {error && (
          <p className="form-error" id="pin-error">
            {error}
          </p>
        )}

        <button type="submit" className="primary-button" disabled={loading || !pin}>
          {loading ? 'Even kijken...' : 'Openen'}
        </button>

        <Link to="/" className="back-link">
          <ArrowLeft size={18} /> Terug naar het eiland
        </Link>
      </form>
    </div>
  );
}

function ParentDashboard({
  summary,
  error,
  onRefresh,
  onLogout,
}: {
  summary: ParentSummary | null;
  error: string | null;
  onRefresh: () => Promise<void>;
  onLogout: () => Promise<void>;
}) {
  const [name, setName] = useState(summary?.settings.childName ?? 'Jaren');
  const [theme, setTheme] = useState(summary?.settings.theme ?? 'mix');
  const [settingsMessage, setSettingsMessage] = useState<string | null>(null);
  const [pin, setPin] = useState('');
  const [pinConfirm, setPinConfirm] = useState('');
  const [pinMessage, setPinMessage] = useState<string | null>(null);
  const [pinError, setPinError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!summary) return;
    setName(summary.settings.childName);
    setTheme(summary.settings.theme);
  }, [summary]);

  async function saveSettings(event: FormEvent) {
    event.preventDefault();
    setBusy(true);
    setSettingsMessage(null);
    try {
      await saveParentSettings({ childName: name.trim(), theme });
      await onRefresh();
      setSettingsMessage('Bewaard.');
    } catch (caught) {
      setSettingsMessage(
        caught instanceof Error ? caught.message : 'Bewaren lukte niet.',
      );
    } finally {
      setBusy(false);
    }
  }

  async function savePin(event: FormEvent) {
    event.preventDefault();
    setPinError(null);
    setPinMessage(null);
    if (!/^\d{4,8}$/.test(pin)) {
      setPinError('Kies 4 tot 8 cijfers.');
      return;
    }
    if (pin !== pinConfirm) {
      setPinError('De twee PIN-codes zijn niet hetzelfde.');
      return;
    }
    setBusy(true);
    try {
      await changeParentPin(pin);
      setPin('');
      setPinConfirm('');
      setPinMessage('PIN aangepast.');
      await onRefresh();
    } catch (caught) {
      setPinError(caught instanceof Error ? caught.message : 'Aanpassen lukte niet.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="app-page parent-page">
      <PageHeader
        icon="🛡️"
        title="Voor mama & papa"
        subtitle="De voortgang en instellingen van Jarens Eiland."
        accent="#fbbf24"
        speech="Dit is het ouderportaal van Jarens Eiland."
      />

      <div className="parent-actions">
        <button type="button" className="secondary-button" onClick={() => void onRefresh()}>
          <RefreshCw size={17} /> Verversen
        </button>
        <button type="button" className="secondary-button" onClick={() => void onLogout()}>
          <LogOut size={17} /> Uitloggen
        </button>
      </div>

      {summary?.parent.pinIsDefault && (
        <div className="parent-warning">
          <KeyRound size={20} />
          <span>
            Je gebruikt nog de standaard-PIN. Kies hieronder een eigen PIN, zodat
            alleen mama en papa binnen kunnen.
          </span>
        </div>
      )}

      {error && <p className="form-error">{error}</p>}

      {summary && (
        <>
          <div className="stat-grid">
            <div className="stat-card">
              <Star size={22} />
              <span className="stat-value">{summary.stars}</span>
              <span className="stat-label">sterren</span>
            </div>
            <div className="stat-card">
              <Sun size={22} />
              <span className="stat-value">{summary.checkins}</span>
              <span className="stat-label">dagchecks</span>
            </div>
            <div className="stat-card">
              <Gamepad2 size={22} />
              <span className="stat-value">{summary.games}</span>
              <span className="stat-label">spelletjes</span>
            </div>
            <div className="stat-card">
              <Activity size={22} />
              <span className="stat-value">{summary.events}</span>
              <span className="stat-label">momenten</span>
            </div>
          </div>

          <p className="muted star-breakdown">
            Sterren in de planner: {summary.plannerStars}. Via dagcheck en leerspellen
            verdiend: {summary.earnedStars}.
          </p>

          <div className="two-column">
            <section className="panel">
              <div className="panel-heading">
                <h2>Laatste activiteit</h2>
                <span className="muted">Nieuwste eerst</span>
              </div>
              {summary.recent.length === 0 ? (
                <p className="muted">
                  Nog geen activiteit. Zodra Jaren een dagcheck doet of een spelletje
                  speelt, zie je het hier.
                </p>
              ) : (
                <ul className="activity-list">
                  {summary.recent.map((event) => (
                    <li key={event.id}>
                      <span className="activity-emoji" aria-hidden="true">
                        {eventEmoji(event)}
                      </span>
                      <span className="activity-copy">
                        <strong>{eventTitle(event)}</strong>
                        <span>{formatWhen(event.created_at)}</span>
                      </span>
                      {event.stars > 0 && (
                        <span className="activity-stars">+{event.stars} ★</span>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section className="panel">
              <h2>Instellingen</h2>
              <form onSubmit={(event) => void saveSettings(event)} className="stack-form">
                <label className="field-label" htmlFor="child-name">
                  Naam van het kind
                </label>
                <input
                  id="child-name"
                  className="text-input"
                  value={name}
                  onChange={(event) => setName(event.target.value)}
                  maxLength={40}
                />

                <label className="field-label" htmlFor="theme">
                  Sfeer
                </label>
                <select
                  id="theme"
                  className="text-input"
                  value={theme}
                  onChange={(event) => setTheme(event.target.value)}
                >
                  <option value="mix">Mix: onderwater + blokken</option>
                  <option value="blocks">Blokkenwereld</option>
                  <option value="underwater">Onderwaterwereld</option>
                </select>

                <button type="submit" className="primary-button" disabled={busy}>
                  {busy ? 'Even bewaren...' : 'Bewaren'}
                </button>
                {settingsMessage && (
                  <p className="form-success">
                    <Check size={16} /> {settingsMessage}
                  </p>
                )}
              </form>
            </section>
          </div>

          <div className="two-column">
            <section className="panel">
              <h2>
                <KeyRound size={20} /> PIN aanpassen
              </h2>
              <p className="muted">
                Kies 4 tot 8 cijfers. Deel de PIN alleen met mama en papa.
              </p>
              <form onSubmit={(event) => void savePin(event)} className="stack-form">
                <label className="field-label" htmlFor="new-pin">
                  Nieuwe PIN
                </label>
                <input
                  id="new-pin"
                  className="pin-input"
                  type="password"
                  value={pin}
                  onChange={(event) => setPin(event.target.value.replace(/\D/g, '').slice(0, 8))}
                  inputMode="numeric"
                  autoComplete="new-password"
                  maxLength={8}
                />
                <label className="field-label" htmlFor="confirm-pin">
                  Nog eens
                </label>
                <input
                  id="confirm-pin"
                  className="pin-input"
                  type="password"
                  value={pinConfirm}
                  onChange={(event) =>
                    setPinConfirm(event.target.value.replace(/\D/g, '').slice(0, 8))
                  }
                  inputMode="numeric"
                  autoComplete="new-password"
                  maxLength={8}
                />
                {pinError && <p className="form-error">{pinError}</p>}
                {pinMessage && (
                  <p className="form-success">
                    <Check size={16} /> {pinMessage}
                  </p>
                )}
                <button type="submit" className="primary-button" disabled={busy}>
                  PIN bewaren
                </button>
              </form>
            </section>

            <section className="panel">
              <h2>
                <ShieldCheck size={20} /> Back-up
              </h2>
              <p className="muted">
                Bewaar een kopie van de planner, alle sterren, dagchecks en
                spelresultaten. Zet het bestand op een veilige plek.
              </p>
              <a className="secondary-button" href="/api/parent/export" download>
                <Download size={17} /> Back-up downloaden
              </a>
              <p className="fine-print">
                Importeren en automatische back-ups komen in een volgende stap.
              </p>
            </section>
          </div>
        </>
      )}

      <Link to="/" className="back-link">
        <ArrowLeft size={18} /> Terug naar het eiland
      </Link>
    </div>
  );
}
