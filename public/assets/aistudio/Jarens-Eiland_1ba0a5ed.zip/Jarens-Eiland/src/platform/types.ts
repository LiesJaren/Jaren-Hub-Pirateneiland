import type { ComponentType } from 'react';

export type AppManifest = {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  color: string;
  route: string;
  order: number;
  component: ComponentType;
};

export type PlatformEvent = {
  id: number;
  app: string;
  type: string;
  payload: Record<string, unknown>;
  stars: number;
  created_at: string;
};

export type PublicSettings = {
  childName: string;
  theme: string;
  platformName: string;
};

export type Summary = {
  stars: number;
  earnedStars: number;
  plannerStars: number;
  events: number;
  checkins: number;
  games: number;
  recent: PlatformEvent[];
  settings: PublicSettings;
};

export type ParentSummary = Summary & {
  parent: {
    pinIsDefault: boolean;
  };
};

export type NewEvent = {
  app: string;
  type: string;
  payload?: Record<string, unknown>;
  stars?: number;
};
