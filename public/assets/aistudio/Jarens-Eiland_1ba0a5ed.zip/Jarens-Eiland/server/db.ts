import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';

const dataDir =
  process.env.JAREN_DATA_DIR ?? join(homedir(), '.local', 'share', 'jarens-eiland');

mkdirSync(dataDir, { recursive: true });

export const db = new DatabaseSync(join(dataDir, 'platform.db'));

db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    app TEXT NOT NULL,
    type TEXT NOT NULL,
    payload TEXT NOT NULL DEFAULT '{}',
    stars INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE INDEX IF NOT EXISTS idx_events_created_at ON events(created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_events_app ON events(app);

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS planner_data (
    planner_id TEXT PRIMARY KEY,
    data TEXT NOT NULL,
    revision INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
  );
`);

export function getSetting(key: string): string | undefined {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key) as
    | { value: string }
    | undefined;
  return row?.value;
}

export function setSetting(key: string, value: string): void {
  db.prepare(
    'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
  ).run(key, value);
}

function ensureSetting(key: string, value: string): void {
  if (getSetting(key) === undefined) setSetting(key, value);
}

ensureSetting('childName', 'Jaren');
ensureSetting('theme', 'mix');
ensureSetting('pin', '1234');
ensureSetting('sessionSecret', randomBytes(32).toString('hex'));
ensureSetting('platformName', "Jaren's Eiland");

export function getPublicSettings(): { childName: string; theme: string; platformName: string } {
  return {
    childName: getSetting('childName') ?? 'Jaren',
    theme: getSetting('theme') ?? 'mix',
    platformName: getSetting('platformName') ?? "Jaren's Eiland",
  };
}
