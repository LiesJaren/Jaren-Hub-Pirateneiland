import { createHmac, timingSafeEqual } from 'node:crypto';
import type { Request, Response } from 'express';
import { getSetting, setSetting } from './db';

export const PARENT_COOKIE = 'jaren_parent';

function sessionSecret(): string {
  let secret = getSetting('sessionSecret');
  if (!secret) {
    secret = createHmac('sha256', 'jarens-eiland').update(String(Date.now())).digest('hex');
    setSetting('sessionSecret', secret);
  }
  return secret;
}

export function parentToken(): string {
  const pin = getSetting('pin') ?? '1234';
  return createHmac('sha256', sessionSecret()).update(pin).digest('hex');
}

export function verifyPin(input: string): boolean {
  const expected = Buffer.from(getSetting('pin') ?? '1234');
  const actual = Buffer.from(input);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

function parseCookies(header: string | undefined): Record<string, string> {
  if (!header) return {};
  const result: Record<string, string> = {};
  for (const part of header.split(';')) {
    const index = part.indexOf('=');
    if (index === -1) continue;
    const key = part.slice(0, index).trim();
    const value = part.slice(index + 1).trim();
    if (key) result[key] = decodeURIComponent(value);
  }
  return result;
}

export function isParent(req: Request): boolean {
  return parseCookies(req.headers.cookie)[PARENT_COOKIE] === parentToken();
}

export function setParentCookie(res: Response): void {
  res.setHeader(
    'Set-Cookie',
    `${PARENT_COOKIE}=${parentToken()}; HttpOnly; SameSite=Lax; Path=/; Max-Age=86400`,
  );
}

export function clearParentCookie(res: Response): void {
  res.setHeader(
    'Set-Cookie',
    `${PARENT_COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`,
  );
}
