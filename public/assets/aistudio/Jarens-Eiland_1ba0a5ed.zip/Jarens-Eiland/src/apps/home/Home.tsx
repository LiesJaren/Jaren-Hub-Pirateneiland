import type { CSSProperties } from 'react';
import { Link } from 'react-router-dom';
import { RefreshCw } from 'lucide-react';
import { useSpeech } from '../../platform/useSpeech';
import { usePlatform } from '../../platform/PlatformContext';

type HubTile = {
  id: string;
  title: string;
  icon: string;
  color: string;
  to: string;
};

const hubTiles: HubTile[] = [
  {
    id: 'planner',
    title: 'Planner',
    icon: '📅',
    color: '#2F7DE1',
    to: '/planner',
  },
  {
    id: 'dagcheck',
    title: 'Dagcheck',
    icon: '🌅',
    color: '#E39A00',
    to: '/dagcheck',
  },
  {
    id: 'gevoelens',
    title: 'Gevoelens',
    icon: '💛',
    color: '#D9437F',
    to: '/gevoelens',
  },
  {
    id: 'lezen',
    title: 'Lezen',
    icon: '📖',
    color: '#7355CC',
    to: '/leren?vak=lezen',
  },
  {
    id: 'schrijven',
    title: 'Schrijven',
    icon: '✏️',
    color: '#139A6F',
    to: '/leren?vak=schrijven',
  },
  {
    id: 'rekenen',
    title: 'Rekenen',
    icon: '🔢',
    color: '#E05A2B',
    to: '/leren?vak=rekenen',
  },
];

export function Home() {
  const { error, refresh } = usePlatform();
  const speak = useSpeech();

  return (
    <div className="hub-home">
      <h2 className="sr-only">Kies een eiland</h2>

      {error && (
        <div className="server-banner" role="status">
          <span>De server is even niet bereikbaar. Je kunt wel rondkijken.</span>
          <button type="button" onClick={() => void refresh()}>
            <RefreshCw size={16} /> Opnieuw
          </button>
        </div>
      )}

      <div className="hub-grid">
        {hubTiles.map((tile) => (
          <Link
            key={tile.id}
            to={tile.to}
            className="hub-tile"
            style={{ '--tile-color': tile.color } as CSSProperties}
            onClick={() => speak(tile.title)}
          >
            <span className="hub-tile-icon" aria-hidden="true">
              {tile.icon}
            </span>
            <span className="hub-tile-title">{tile.title}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
