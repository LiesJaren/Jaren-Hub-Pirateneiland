#!/usr/bin/env bash
# Start het eiland in een eigen Chrome-venster. Wordt gebruikt door de
# automatische start en door de menu snelkoppeling.
set -euo pipefail

PORT="${PORT:-3000}"
URL="http://localhost:${PORT}"

if command -v curl >/dev/null 2>&1; then
  for _ in $(seq 1 40); do
    if curl -fsS "http://localhost:${PORT}/api/health" >/dev/null 2>&1; then
      break
    fi
    sleep 1
  done
fi

BROWSER=""
for candidate in google-chrome google-chrome-stable chromium chromium-browser; do
  if command -v "$candidate" >/dev/null 2>&1; then
    BROWSER="$candidate"
    break
  fi
done

if [[ -z "$BROWSER" ]]; then
  echo "Geen Chrome of Chromium gevonden." >&2
  exit 1
fi

exec "$BROWSER" \
  --app="$URL" \
  --start-fullscreen \
  --no-first-run \
  --no-default-browser-check \
  --disable-features=Translate
