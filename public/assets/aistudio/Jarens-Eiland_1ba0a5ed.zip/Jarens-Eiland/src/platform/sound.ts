let audioContext: AudioContext | null = null;

function context(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AudioContextClass =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;
  audioContext ??= new AudioContextClass();
  if (audioContext.state === 'suspended') void audioContext.resume();
  return audioContext;
}

function tone(
  frequency: number,
  start: number,
  duration: number,
  volume = 0.08,
  type: OscillatorType = 'sine',
): void {
  const ctx = context();
  if (!ctx) return;
  const oscillator = ctx.createOscillator();
  const gain = ctx.createGain();
  oscillator.type = type;
  oscillator.frequency.value = frequency;
  gain.gain.setValueAtTime(0.0001, ctx.currentTime + start);
  gain.gain.exponentialRampToValueAtTime(volume, ctx.currentTime + start + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + duration);
  oscillator.connect(gain);
  gain.connect(ctx.destination);
  oscillator.start(ctx.currentTime + start);
  oscillator.stop(ctx.currentTime + start + duration + 0.02);
}

export function playPop(): void {
  tone(520, 0, 0.1, 0.05, 'triangle');
  tone(780, 0.06, 0.12, 0.04, 'triangle');
}

export function playSuccess(): void {
  tone(523.25, 0, 0.18);
  tone(659.25, 0.1, 0.18);
  tone(783.99, 0.2, 0.26);
  tone(1046.5, 0.32, 0.35, 0.06);
}

export function playOops(): void {
  tone(220, 0, 0.18, 0.05, 'sine');
  tone(174.61, 0.12, 0.24, 0.05, 'sine');
}
