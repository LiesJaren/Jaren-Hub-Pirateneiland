import type {
  NewEvent,
  ParentSummary,
  PlatformEvent,
  PublicSettings,
  Summary,
} from './types';

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    credentials: 'same-origin',
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers ?? {}),
    },
    ...options,
  });

  let body: unknown = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }

  if (!response.ok) {
    const message =
      body && typeof body === 'object' && 'error' in body
        ? String((body as { error: unknown }).error)
        : `De server antwoordde met ${response.status}.`;
    throw new Error(message);
  }

  return body as T;
}

export function getSummary(): Promise<Summary> {
  return request<Summary>('/api/summary');
}

export function getEvents(app?: string, limit = 50): Promise<{ events: PlatformEvent[] }> {
  const params = new URLSearchParams({ limit: String(limit) });
  if (app) params.set('app', app);
  return request<{ events: PlatformEvent[] }>(`/api/events?${params.toString()}`);
}

export function addEvent(
  event: NewEvent,
): Promise<{ event: PlatformEvent; summary: Summary }> {
  return request('/api/events', {
    method: 'POST',
    body: JSON.stringify(event),
  });
}

export function getParentSession(): Promise<{ authenticated: boolean }> {
  return request('/api/parent/session');
}

export function parentLogin(pin: string): Promise<{ ok: true }> {
  return request('/api/parent/login', {
    method: 'POST',
    body: JSON.stringify({ pin }),
  });
}

export function parentLogout(): Promise<{ ok: true }> {
  return request('/api/parent/logout', { method: 'POST' });
}

export function getParentSummary(): Promise<ParentSummary> {
  return request('/api/parent/summary');
}

export function changeParentPin(pin: string): Promise<{ ok: true }> {
  return request('/api/parent/pin', {
    method: 'PUT',
    body: JSON.stringify({ pin }),
  });
}

export function saveParentSettings(settings: {
  childName?: string;
  theme?: string;
}): Promise<{ settings: PublicSettings }> {
  return request('/api/parent/settings', {
    method: 'PUT',
    body: JSON.stringify(settings),
  });
}
