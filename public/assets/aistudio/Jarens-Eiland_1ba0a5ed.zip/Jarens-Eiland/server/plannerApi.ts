import { Router } from 'express';
import { db, getSetting } from './db';

const PLANNER_ID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type PlannerRow = {
  data: string;
  revision: number;
};

type PlannerRequest = {
  members: unknown;
  events: unknown;
  groceries: unknown;
  rewards: unknown;
  customIcons: unknown;
  customCategories: unknown;
  customRoutines: unknown;
  preferences?: unknown;
};

function plannerIdFromQuery(value: unknown): string | null {
  return typeof value === 'string' && PLANNER_ID.test(value) ? value : null;
}

function isPlannerData(value: unknown): value is PlannerRequest {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const data = value as Record<string, unknown>;
  const requiredArrays = [
    'members',
    'events',
    'groceries',
    'rewards',
    'customIcons',
    'customCategories',
    'customRoutines',
  ];
  if (!requiredArrays.every((key) => Array.isArray(data[key]))) return false;
  return (
    data.preferences === undefined ||
    (!!data.preferences && typeof data.preferences === 'object' && !Array.isArray(data.preferences))
  );
}

function readPlanner(id: string): PlannerRow | undefined {
  return db
    .prepare('SELECT data, revision FROM planner_data WHERE planner_id = ?')
    .get(id) as PlannerRow | undefined;
}

function parseStored(row: PlannerRow | undefined): unknown {
  if (!row) return null;
  try {
    return JSON.parse(row.data);
  } catch {
    return null;
  }
}

export const plannerApi = Router();

plannerApi.use((_req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
});

plannerApi.get('/default', (_req, res) => {
  const plannerId = getSetting('defaultPlannerId') ?? null;
  res.json({ plannerId: plannerId && PLANNER_ID.test(plannerId) ? plannerId : null });
});

plannerApi.get('/', (req, res) => {
  const plannerId = plannerIdFromQuery(req.query.planner);
  if (!plannerId) {
    res.status(400).json({ error: 'Ongeldige planner-id.' });
    return;
  }

  const row = readPlanner(plannerId);

  if (req.query.meta === '1') {
    res.json({ revision: row?.revision ?? 0 });
    return;
  }

  res.json({ data: parseStored(row), revision: row?.revision ?? 0 });
});

plannerApi.post('/', (req, res) => {
  const plannerId = plannerIdFromQuery(req.query.planner);
  if (!plannerId) {
    res.status(400).json({ error: 'Ongeldige planner-id.' });
    return;
  }

  const body = req.body ?? {};
  const data: unknown = body.data;
  const expectedRevision = Number(body.expectedRevision);

  if (!isPlannerData(data)) {
    res.status(400).json({ error: 'Ongeldige plannergegevens.' });
    return;
  }
  if (!Number.isInteger(expectedRevision) || expectedRevision < 0) {
    res.status(400).json({ error: 'Ongeldig versienummer.' });
    return;
  }

  const current = readPlanner(plannerId);
  const currentRevision = current?.revision ?? 0;

  // Node voert synchrone SQLite-code niet tegelijk uit. Deze controle en de
  // schrijfactie hieronder vormen daardoor samen één veilige transactie.
  if (currentRevision !== expectedRevision) {
    res.status(409).json({
      data: parseStored(current),
      revision: currentRevision,
    });
    return;
  }

  const revision = currentRevision + 1;
  const stored = JSON.stringify({ ...data, revision });

  db.prepare(
    `INSERT INTO planner_data (planner_id, data, revision, updated_at)
     VALUES (?, ?, ?, ?)
     ON CONFLICT(planner_id) DO UPDATE SET
       data = excluded.data,
       revision = excluded.revision,
       updated_at = excluded.updated_at`,
  ).run(plannerId, stored, revision, new Date().toISOString());

  res.json({ revision });
});
