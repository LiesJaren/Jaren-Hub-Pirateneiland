import { Router } from 'express';
import { spawn, spawnSync } from 'node:child_process';
import { db, getPublicSettings, getSetting, setSetting } from './db';
import { plannerApi } from './plannerApi';
import {
  adjustPlannerChildStars,
  ensurePlannerStarsBackfilled,
  getPlannerChildStars,
} from './stars';
import {
  clearParentCookie,
  isParent,
  setParentCookie,
  verifyPin,
} from './session';

export const api = Router();

type EventRow = {
  id: number;
  app: string;
  type: string;
  payload: string;
  stars: number;
  created_at: string;
};

function parseEvent(row: EventRow) {
  let payload: unknown = {};
  try {
    payload = JSON.parse(row.payload);
  } catch {
    payload = {};
  }
  return { ...row, payload };
}

function getSummary(limit = 12) {
  const totals = db
    .prepare(
      `SELECT
         COALESCE(SUM(stars), 0) AS stars,
         COUNT(*) AS events,
         COALESCE(SUM(CASE WHEN type = 'checkin' THEN 1 ELSE 0 END), 0) AS checkins,
         COALESCE(SUM(CASE WHEN type = 'game.completed' THEN 1 ELSE 0 END), 0) AS games
       FROM events`,
    )
    .get() as { stars: number; events: number; checkins: number; games: number };

  const recent = db
    .prepare(
      `SELECT id, app, type, payload, stars, created_at
       FROM events
       ORDER BY id DESC
       LIMIT ?`,
    )
    .all(limit) as EventRow[];

  ensurePlannerStarsBackfilled();
  const earnedStars = totals.stars;
  const plannerStars = getPlannerChildStars();

  return {
    ...totals,
    stars: plannerStars ?? earnedStars,
    earnedStars,
    plannerStars: plannerStars ?? 0,
    recent: recent.map(parseEvent),
    settings: getPublicSettings(),
  };
}

function requireParent(req: Parameters<typeof isParent>[0], res: import('express').Response) {
  if (!isParent(req)) {
    res.status(401).json({ error: 'Alleen voor mama of papa.' });
    return false;
  }
  return true;
}

api.use('/planner', plannerApi);

api.get('/health', (_req, res) => {
  res.json({ ok: true, app: "Jaren's Eiland" });
});

// Lokale systeemstem voor Chrome/Chromium op Linux zonder bruikbare
// browserstem. De planner gebruikt dit als terugvaloptie.
api.post('/speak', (req, res) => {
  const text = typeof req.body?.text === 'string' ? req.body.text.trim() : '';
  if (!text) {
    res.status(400).json({ ok: false, error: 'Tekst is verplicht' });
    return;
  }
  if (text.length > 800) {
    res.status(400).json({ ok: false, error: 'Tekst is te lang' });
    return;
  }
  if (process.platform !== 'linux') {
    res.status(503).json({
      ok: false,
      error: 'Systeemstem is alleen lokaal op Linux beschikbaar',
    });
    return;
  }

  const cancel = spawnSync('spd-say', ['-C'], { stdio: 'ignore', timeout: 1500 });
  if (cancel.error) {
    res.status(503).json({
      ok: false,
      error: 'Systeemstem (spd-say) is niet gevonden',
    });
    return;
  }

  try {
    const child = spawn(
      'spd-say',
      ['-l', 'nl', '-r', '-10', '-p', '5', '-i', '20', text],
      { detached: true, stdio: 'ignore' },
    );
    child.on('error', (error) => console.warn('Systeemstem kon niet starten:', error));
    child.unref();
    res.json({ ok: true });
  } catch (error) {
    console.warn('Systeemstem kon niet starten:', error);
    res.status(503).json({ ok: false, error: 'Systeemstem niet beschikbaar' });
  }
});

api.get('/summary', (_req, res) => {
  res.json(getSummary());
});

api.get('/events', (req, res) => {
  const app = typeof req.query.app === 'string' ? req.query.app : undefined;
  const requestedLimit = Number(req.query.limit ?? 50);
  const limit = Number.isFinite(requestedLimit)
    ? Math.min(Math.max(Math.trunc(requestedLimit), 1), 200)
    : 50;

  const rows = app
    ? (db
        .prepare(
          `SELECT id, app, type, payload, stars, created_at
           FROM events WHERE app = ? ORDER BY id DESC LIMIT ?`,
        )
        .all(app, limit) as EventRow[])
    : (db
        .prepare(
          `SELECT id, app, type, payload, stars, created_at
           FROM events ORDER BY id DESC LIMIT ?`,
        )
        .all(limit) as EventRow[]);

  res.json({ events: rows.map(parseEvent) });
});

api.post('/events', (req, res) => {
  const body = req.body ?? {};
  const app = String(body.app ?? '').trim();
  const type = String(body.type ?? '').trim();
  const stars = Number.isFinite(Number(body.stars))
    ? Math.min(Math.max(Math.trunc(Number(body.stars)), 0), 10)
    : 0;
  const payload =
    body.payload && typeof body.payload === 'object' && !Array.isArray(body.payload)
      ? body.payload
      : {};

  if (!app || app.length > 40 || !type || type.length > 60) {
    res.status(400).json({ error: 'Ongeldige gebeurtenis.' });
    return;
  }

  const createdAt = new Date().toISOString();
  const result = db
    .prepare(
      `INSERT INTO events (app, type, payload, stars, created_at)
       VALUES (?, ?, ?, ?, ?)`,
    )
    .run(app, type, JSON.stringify(payload), stars, createdAt);

  if (stars > 0) adjustPlannerChildStars(stars);

  const event = db
    .prepare(
      `SELECT id, app, type, payload, stars, created_at FROM events WHERE id = ?`,
    )
    .get(Number(result.lastInsertRowid)) as EventRow;

  res.status(201).json({ event: parseEvent(event), summary: getSummary() });
});

api.get('/parent/session', (req, res) => {
  res.json({ authenticated: isParent(req) });
});

api.post('/parent/login', (req, res) => {
  const pin = String(req.body?.pin ?? '').trim();
  if (!verifyPin(pin)) {
    res.status(401).json({ error: 'Die PIN klopt niet.' });
    return;
  }
  setParentCookie(res);
  res.json({ ok: true });
});

api.post('/parent/logout', (_req, res) => {
  clearParentCookie(res);
  res.json({ ok: true });
});

api.get('/parent/summary', (req, res) => {
  if (!requireParent(req, res)) return;
  res.json({
    ...getSummary(40),
    parent: {
      pinIsDefault: getSetting('pin') === '1234',
    },
  });
});

api.put('/parent/pin', (req, res) => {
  if (!requireParent(req, res)) return;
  const pin = String(req.body?.pin ?? '').trim();
  if (!/^\d{4,8}$/.test(pin)) {
    res.status(400).json({ error: 'Kies een PIN van 4 tot 8 cijfers.' });
    return;
  }
  setSetting('pin', pin);
  setParentCookie(res);
  res.json({ ok: true });
});

api.put('/parent/settings', (req, res) => {
  if (!requireParent(req, res)) return;
  const childName = req.body?.childName;
  const theme = req.body?.theme;

  if (childName !== undefined) {
    const name = String(childName).trim();
    if (!name || name.length > 40) {
      res.status(400).json({ error: 'Die naam is niet geldig.' });
      return;
    }
    setSetting('childName', name);
  }

  if (theme !== undefined) {
    const allowed = new Set(['mix', 'blocks', 'underwater']);
    if (!allowed.has(String(theme))) {
      res.status(400).json({ error: 'Onbekende sfeer.' });
      return;
    }
    setSetting('theme', String(theme));
  }

  res.json({ settings: getPublicSettings() });
});

api.get('/parent/export', (req, res) => {
  if (!requireParent(req, res)) return;
  const events = db
    .prepare(
      `SELECT id, app, type, payload, stars, created_at
       FROM events ORDER BY id`,
    )
    .all() as EventRow[];

  const plannerId = getSetting('defaultPlannerId');
  let planner: unknown = null;
  if (plannerId) {
    const row = db
      .prepare('SELECT data, revision FROM planner_data WHERE planner_id = ?')
      .get(plannerId) as { data: string; revision: number } | undefined;
    if (row) {
      try {
        planner = {
          plannerId,
          revision: row.revision,
          data: JSON.parse(row.data),
        };
      } catch {
        planner = null;
      }
    }
  }

  res.setHeader(
    'Content-Disposition',
    'attachment; filename="jarens-eiland-backup.json"',
  );
  res.json({
    format: 'jarens-eiland',
    version: 2,
    exportedAt: new Date().toISOString(),
    settings: getPublicSettings(),
    planner,
    events: events.map(parseEvent),
  });
});

api.use((_req, res) => {
  res.status(404).json({ error: 'Onbekend API-pad.' });
});
