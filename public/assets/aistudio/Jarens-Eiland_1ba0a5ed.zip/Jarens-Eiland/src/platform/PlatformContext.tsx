import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { addEvent as postEvent, getSummary } from './api';
import type { NewEvent, Summary } from './types';

type PlatformContextValue = {
  summary: Summary | null;
  loading: boolean;
  error: string | null;
  refresh: () => Promise<void>;
  addEvent: (event: NewEvent) => Promise<Summary>;
  childName: string;
  stars: number;
  theme: string;
};

const PlatformContext = createContext<PlatformContextValue | null>(null);

const fallback: PlatformContextValue = {
  summary: null,
  loading: true,
  error: null,
  refresh: async () => undefined,
  addEvent: async () => {
    throw new Error('De server is nog niet klaar.');
  },
  childName: 'Jaren',
  stars: 0,
  theme: 'mix',
};

// De balans staat in de planner. Als Jaren daar sterren verdient of inwisselt,
// moet het eiland dat meteen laten zien zodra hij terugkomt.

export function PlatformProvider({ children }: { children: ReactNode }) {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const next = await getSummary();
      setSummary(next);
      setError(null);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : 'De server is niet bereikbaar.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  useEffect(() => {
    const onFocus = () => void refresh();
    const onVisibilityChange = () => {
      if (document.visibilityState === 'visible') void refresh();
    };
    window.addEventListener('focus', onFocus);
    document.addEventListener('visibilitychange', onVisibilityChange);
    return () => {
      window.removeEventListener('focus', onFocus);
      document.removeEventListener('visibilitychange', onVisibilityChange);
    };
  }, [refresh]);

  const addEvent = useCallback(async (event: NewEvent) => {
    const result = await postEvent(event);
    setSummary(result.summary);
    setError(null);
    return result.summary;
  }, []);

  const value = useMemo<PlatformContextValue>(() => {
    if (!summary) {
      return { ...fallback, loading, error, refresh, addEvent };
    }
    return {
      summary,
      loading,
      error,
      refresh,
      addEvent,
      childName: summary.settings.childName,
      stars: summary.stars,
      theme: summary.settings.theme,
    };
  }, [summary, loading, error, refresh, addEvent]);

  return <PlatformContext.Provider value={value}>{children}</PlatformContext.Provider>;
}

export function usePlatform(): PlatformContextValue {
  return useContext(PlatformContext) ?? fallback;
}
