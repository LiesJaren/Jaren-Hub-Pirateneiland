const bubbles = [
  { left: '6%', size: 18, delay: '0s', duration: '13s' },
  { left: '14%', size: 9, delay: '4s', duration: '11s' },
  { left: '24%', size: 26, delay: '8s', duration: '17s' },
  { left: '37%', size: 12, delay: '2s', duration: '15s' },
  { left: '49%', size: 8, delay: '10s', duration: '12s' },
  { left: '61%', size: 22, delay: '6s', duration: '18s' },
  { left: '72%', size: 10, delay: '1s', duration: '14s' },
  { left: '83%', size: 30, delay: '9s', duration: '20s' },
  { left: '92%', size: 13, delay: '3s', duration: '16s' },
];

function Island() {
  return (
    <svg
      className="island-svg"
      viewBox="0 0 1200 360"
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <g shapeRendering="crispEdges">
        <rect x="0" y="252" width="1200" height="108" fill="#0e7490" opacity="0.28" />
        <path d="M0 292 L110 278 L210 300 L330 282 L460 304 L590 286 L720 306 L850 284 L980 302 L1100 282 L1200 296 L1200 360 L0 360 Z" fill="#0369a1" opacity="0.45" />
        <path d="M0 318 L90 306 L190 326 L300 310 L420 330 L540 314 L670 332 L800 312 L930 330 L1050 312 L1200 326 L1200 360 L0 360 Z" fill="#0c4a6e" opacity="0.55" />
        <path d="M760 282 L820 282 L820 300 L760 300 Z" fill="#fcd34d" opacity="0.55" />
        <path d="M820 268 L930 268 L930 300 L820 300 Z" fill="#fbbf24" opacity="0.45" />
        <path d="M880 246 L1000 246 L1000 268 L880 268 Z" fill="#84cc16" opacity="0.35" />
        <path d="M930 228 L1018 228 L1018 246 L930 246 Z" fill="#65a30d" opacity="0.28" />
        <path d="M135 288 L245 288 L245 304 L135 304 Z" fill="#fcd34d" opacity="0.32" />
        <path d="M175 270 L280 270 L280 288 L175 288 Z" fill="#fbbf24" opacity="0.24" />
      </g>
    </svg>
  );
}

export function OceanBackground() {
  return (
    <div className="ocean-bg" aria-hidden="true">
      <div className="ocean-glow ocean-glow-one" />
      <div className="ocean-glow ocean-glow-two" />
      <div className="sun-glow" />
      {bubbles.map((bubble, index) => (
        <span
          key={index}
          className="bubble"
          style={{
            left: bubble.left,
            width: bubble.size,
            height: bubble.size,
            animationDelay: bubble.delay,
            animationDuration: bubble.duration,
          }}
        />
      ))}
      <Island />
    </div>
  );
}
