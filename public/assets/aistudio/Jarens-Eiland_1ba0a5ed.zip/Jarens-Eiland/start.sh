#!/bin/sh
# Start Jarens Eiland (productiebuild) en open het in een eigen venster.
set -u

cd "$(dirname "$0")" || exit 1
PORT="${PORT:-3002}"
URL="http://localhost:$PORT"
PROFILE="$HOME/.config/jarens-eiland-app"

# Node staat niet altijd op het PATH.
if ! command -v node >/dev/null 2>&1; then
  for candidate in \
    "$HOME/.local/opt"/node-*/bin \
    "$HOME/.nvm/versions/node"/*/bin \
    "$HOME/node/bin" \
    /usr/local/node/bin
  do
    if [ -x "$candidate/node" ]; then
      PATH="$candidate:$PATH"
      export PATH
      break
    fi
  done
fi

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is niet gevonden. Installeer Node 18 of nieuwer."
  exit 1
fi

open_window() {
  [ "${EILAND_NO_BROWSER:-0}" = "1" ] && return 0
  for browser in google-chrome chromium chromium-browser; do
    if command -v "$browser" >/dev/null 2>&1; then
      "$browser" --app="$URL" --user-data-dir="$PROFILE" --start-fullscreen \
        --no-first-run --no-default-browser-check >/dev/null 2>&1 &
      return 0
    fi
  done
  if command -v xdg-open >/dev/null 2>&1; then
    xdg-open "$URL" >/dev/null 2>&1 &
    return 0
  fi
  echo "Open zelf: $URL"
}

# Draait de app al? Dan alleen het venster openen.
if curl -fsS "$URL/api/health" >/dev/null 2>&1; then
  open_window
  exit 0
fi

if [ ! -f dist/index.html ]; then
  echo "Geen productiebuild gevonden. Draai eerst: npm run build"
  exit 1
fi

PIDS=""
cleanup() {
  for pid in $PIDS; do
    kill "$pid" 2>/dev/null || true
  done
}
trap cleanup EXIT INT TERM

NODE_ENV=production PORT="$PORT" ./node_modules/.bin/tsx server/index.ts &
APP_PID=$!
PIDS="$PIDS $APP_PID"

tries=0
while [ "$tries" -lt 100 ]; do
  if curl -fsS "$URL/api/health" >/dev/null 2>&1; then
    break
  fi
  tries=$((tries + 1))
  sleep 0.1
done

open_window
wait "$APP_PID"
