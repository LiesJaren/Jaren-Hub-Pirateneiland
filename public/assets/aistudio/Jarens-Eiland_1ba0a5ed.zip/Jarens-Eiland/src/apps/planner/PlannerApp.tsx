import { lazy, Suspense } from 'react';
import { Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const EmbeddedPlanner = lazy(() => import('./EmbeddedPlanner'));

export default function PlannerApp() {
  const navigate = useNavigate();

  return (
    <div className="planner-embed">
      <Suspense
        fallback={
          <div className="planner-loading" role="status">
            <span className="planner-loading-dot" aria-hidden="true" />
            Jouw planbord wordt klaargezet...
          </div>
        }
      >
        <EmbeddedPlanner />
      </Suspense>

      <button
        type="button"
        className="planner-home-button no-print"
        onClick={() => navigate('/')}
        aria-label="Terug naar het eiland"
        title="Terug naar het eiland"
      >
        <Home size={21} strokeWidth={2.7} />
        <span>Eiland</span>
      </button>
    </div>
  );
}
