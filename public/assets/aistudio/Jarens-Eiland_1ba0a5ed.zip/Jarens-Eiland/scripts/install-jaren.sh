#!/usr/bin/env bash
#
# Zet Jaren's Eiland klaar in het Linux-account van Jaren.
#
# Gebruik (als root):
#   sudo bash scripts/install-jaren.sh
#
# Optioneel, om meteen de bestaande plannerback-up in te voeren:
#   sudo PLANNER_BACKUP=/pad/naar/familieplanner-backup.json \
#     bash scripts/install-jaren.sh
#
# Het script:
#   - kopieert de app naar /home/<gebruiker>/jarens-eiland;
#   - installeert Node 24 lokaal in dat account;
#   - bouwt de app en start een systemd-gebruikersdienst op poort 3000;
#   - zet een autostart klaar die Chrome in app-modus opent.
#
# De gegevens zelf staan in ~/.local/share/jarens-eiland/platform.db en
# blijven bij een herinstallatie bewaard.
set -euo pipefail

APP_USER="${APP_USER:-superjaren4}"
APP_DIR="${APP_DIR:-/home/${APP_USER}/jarens-eiland}"
NODE_VERSION="${NODE_VERSION:-24.22.1}"
PORT="${PORT:-3000}"

if [[ "${EUID}" -ne 0 ]]; then
  echo "Draai dit script als root: sudo bash scripts/install-jaren.sh" >&2
  exit 1
fi

if ! id "$APP_USER" >/dev/null 2>&1; then
  echo "De gebruiker '$APP_USER' bestaat niet. Pas APP_USER aan." >&2
  exit 1
fi

if [[ "$APP_DIR" != /home/*/jarens-eiland ]]; then
  echo "Onveilige APP_DIR: $APP_DIR" >&2
  exit 1
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -f "$SOURCE_DIR/package.json" ]]; then
  echo "Kon de app niet vinden naast dit script." >&2
  exit 1
fi

TMP_BACKUP=""
cleanup() {
  if [[ -n "$TMP_BACKUP" && -f "$TMP_BACKUP" ]]; then
    rm -f "$TMP_BACKUP"
  fi
}
trap cleanup EXIT

if [[ -n "${PLANNER_BACKUP:-}" ]]; then
  if [[ ! -f "$PLANNER_BACKUP" ]]; then
    echo "Plannerback-up niet gevonden: $PLANNER_BACKUP" >&2
    exit 1
  fi
  TMP_BACKUP="$(mktemp /tmp/jarens-planner-backup.XXXXXX.json)"
  cp "$PLANNER_BACKUP" "$TMP_BACKUP"
  chmod 0644 "$TMP_BACKUP"
fi

APP_UID="$(id -u "$APP_USER")"
APP_GID="$(id -g "$APP_USER")"

echo "→ Gebruikersdienst voorbereiden..."
loginctl enable-linger "$APP_USER" 2>/dev/null || true
for _ in $(seq 1 20); do
  [[ -d "/run/user/$APP_UID" ]] && break
  sleep 0.5
done

echo "→ Bestaande dienst stoppen (als die loopt)..."
runuser -u "$APP_USER" -- env XDG_RUNTIME_DIR="/run/user/$APP_UID" \
  systemctl --user stop jarens-eiland.service 2>/dev/null || true

echo "→ App kopiëren naar $APP_DIR..."
rm -rf "$APP_DIR"
install -d -m 0755 -o "$APP_USER" -g "$APP_USER" "$APP_DIR"
tar -C "$SOURCE_DIR" \
  --exclude='./node_modules' \
  --exclude='./dist' \
  --exclude='./.git' \
  --exclude='./.env' \
  --exclude='./*.log' \
  -cf - . | tar -C "$APP_DIR" -xf -
chown -R "$APP_USER:$APP_USER" "$APP_DIR"
chmod +x "$APP_DIR/scripts/install-jaren.sh" \
  "$APP_DIR/scripts/start-jarens-eiland.sh" 2>/dev/null || true

echo "→ Node, pakketten, build, dienst en autostart klaarzetten..."
runuser -u "$APP_USER" -- bash -c '
  set -euo pipefail
  APP_DIR="$1"
  NODE_VERSION="$2"
  PORT="$3"
  PLANNER_BACKUP_PATH="${4:-}"

  export XDG_RUNTIME_DIR="/run/user/$(id -u)"
  NODE_DIR="$HOME/.local/opt/node"

  if ! "$NODE_DIR/bin/node" -e "require(\"node:sqlite\")" >/dev/null 2>&1; then
    case "$(uname -m)" in
      x86_64) NODE_ARCH="x64" ;;
      aarch64|arm64) NODE_ARCH="arm64" ;;
      *)
        echo "Onbekende processorarchitectuur: $(uname -m)" >&2
        exit 1
        ;;
    esac

    TMP_NODE="$(mktemp -d)"
    NODE_URL="https://nodejs.org/dist/v${NODE_VERSION}/node-v${NODE_VERSION}-linux-${NODE_ARCH}.tar.xz"
    echo "  Node ${NODE_VERSION} downloaden..."
    curl -fsSL "$NODE_URL" -o "$TMP_NODE/node.tar.xz"
    mkdir -p "$HOME/.local/opt"
    tar -xJf "$TMP_NODE/node.tar.xz" -C "$HOME/.local/opt"
    rm -rf "$NODE_DIR"
    mv "$HOME/.local/opt/node-v${NODE_VERSION}-linux-${NODE_ARCH}" "$NODE_DIR"
    rm -rf "$TMP_NODE"
  fi

  export PATH="$NODE_DIR/bin:$PATH"
  echo "  Node: $(node -v)"

  cd "$APP_DIR"
  npm ci --include=dev
  npm rebuild esbuild >/dev/null 2>&1 || true
  npm run build

  mkdir -p "$HOME/.config/systemd/user" "$HOME/.config/autostart" \
    "$HOME/.local/share/applications" \
    "$HOME/.local/share/icons/hicolor/scalable/apps"

  cat > "$HOME/.config/systemd/user/jarens-eiland.service" <<EOF
[Unit]
Description=Jarens Eiland
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR
Environment=NODE_ENV=production
Environment=PORT=$PORT
Environment=PATH=$NODE_DIR/bin:/usr/local/bin:/usr/bin:/bin
ExecStart=/bin/bash -lc 'cd "$APP_DIR" && exec npm start'
Restart=on-failure
RestartSec=3

[Install]
WantedBy=default.target
EOF

  cat > "$HOME/.config/autostart/jarens-eiland.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Jarens Eiland
Comment=Start Jarens eiland en de familieplanner
Exec=/usr/bin/env PORT=$PORT $APP_DIR/scripts/start-jarens-eiland.sh
Terminal=false
X-GNOME-Autostart-enabled=true
EOF

  cp "$APP_DIR/public/icon.svg" \
    "$HOME/.local/share/icons/hicolor/scalable/apps/jarens-eiland.svg"
  cat > "$HOME/.local/share/applications/jarens-eiland.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Jarens Eiland
Comment=Jarens eiland, planner en leerspellen
Exec=/usr/bin/env PORT=$PORT $APP_DIR/scripts/start-jarens-eiland.sh
Icon=jarens-eiland
Terminal=false
Categories=Education;Game;
EOF

  chmod +x "$APP_DIR/scripts/start-jarens-eiland.sh"

  for _ in $(seq 1 15); do
    if systemctl --user daemon-reload 2>/dev/null; then
      break
    fi
    sleep 1
  done
  if ! systemctl --user enable --now jarens-eiland.service; then
    echo "  Let op: de dienst kon nu niet worden gestart." >&2
    echo "  Log in als $USER en voer uit:" >&2
    echo "    systemctl --user enable --now jarens-eiland.service" >&2
  fi

  if [[ -n "$PLANNER_BACKUP_PATH" && -f "$PLANNER_BACKUP_PATH" ]]; then
    echo "  Bestaande planner invoeren..."
    npm run migrate:planner -- "$PLANNER_BACKUP_PATH"
  fi
' _ "$APP_DIR" "$NODE_VERSION" "$PORT" "${TMP_BACKUP:-}"

LAN_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
echo
echo "Klaar."
echo "  Lokaal:       http://localhost:${PORT}"
echo "  Ouderportaal: http://${LAN_IP:-<laptop-ip>}:${PORT}/ouder"
echo "  Autostart:    $APP_DIR/scripts/start-jarens-eiland.sh"
echo
echo "De standaard-PIN is 1234. Verander die meteen in het ouderportaal."
echo "Zet de laptopfirewall indien nodig open voor poort ${PORT}."
