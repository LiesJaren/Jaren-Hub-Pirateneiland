import { db, getSetting, setSetting } from './db';

type PlannerData = Record<string, unknown> & {
  members?: unknown[];
  revision?: number;
};

type PlannerRow = {
  planner_id: string;
  data: string;
  revision: number;
};

function defaultPlannerRow(): PlannerRow | undefined {
  const plannerId = getSetting('defaultPlannerId');
  if (!plannerId) return undefined;
  return db
    .prepare('SELECT planner_id, data, revision FROM planner_data WHERE planner_id = ?')
    .get(plannerId) as PlannerRow | undefined;
}

function parseData(row: PlannerRow): PlannerData | null {
  try {
    const value: unknown = JSON.parse(row.data);
    if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
    return value as PlannerData;
  } catch {
    return null;
  }
}

function childMemberIndex(members: unknown[]): number {
  const index = members.findIndex(
    (member) =>
      !!member &&
      typeof member === 'object' &&
      (member as Record<string, unknown>).role === 'kind',
  );
  if (index >= 0) return index;
  return members.length > 2 ? 2 : -1;
}

/**
 * De sterrenbalans van het kind staat in de planner. Zo gebruiken de planner,
 * de dagcheck en de leerspellen allemaal dezelfde teller.
 */
export function getPlannerChildStars(): number | null {
  const row = defaultPlannerRow();
  if (!row) return null;
  const data = parseData(row);
  if (!data || !Array.isArray(data.members)) return null;
  const index = childMemberIndex(data.members);
  if (index < 0) return null;
  const child = data.members[index];
  if (!child || typeof child !== 'object') return null;
  const stars = Number((child as Record<string, unknown>).stars);
  return Number.isFinite(stars) ? Math.max(0, Math.trunc(stars)) : 0;
}

/**
 * Past de sterrenbalans in de planner aan. De planner ziet de nieuwe revisie
 * bij zijn volgende synchronisatie en neemt de nieuwe stand over.
 */
export function adjustPlannerChildStars(delta: number): number | null {
  if (!Number.isFinite(delta) || delta === 0) return getPlannerChildStars();
  const row = defaultPlannerRow();
  if (!row) return null;
  const data = parseData(row);
  if (!data || !Array.isArray(data.members)) return null;
  const index = childMemberIndex(data.members);
  if (index < 0) return null;

  const child = data.members[index];
  if (!child || typeof child !== 'object') return null;
  const current = Number((child as Record<string, unknown>).stars);
  const safeCurrent = Number.isFinite(current) ? Math.max(0, Math.trunc(current)) : 0;
  const next = Math.max(0, safeCurrent + Math.trunc(delta));
  if (next === safeCurrent) return safeCurrent;

  data.members[index] = { ...(child as Record<string, unknown>), stars: next };
  const revision = row.revision + 1;
  const stored = JSON.stringify({ ...data, revision });

  db.prepare(
    `UPDATE planner_data
     SET data = ?, revision = ?, updated_at = ?
     WHERE planner_id = ?`,
  ).run(stored, revision, new Date().toISOString(), row.planner_id);

  return next;
}

/**
 * Sterren die vóór de koppeling al in het eiland zijn verdiend, tellen we één
 * keer op bij de plannerbalans. Daarna loopt alles via dezelfde teller.
 */
export function ensurePlannerStarsBackfilled(): void {
  if (getSetting('plannerStarsBackfilled') === '1') return;
  if (!defaultPlannerRow()) return;

  const total = db
    .prepare('SELECT COALESCE(SUM(stars), 0) AS stars FROM events')
    .get() as { stars: number };

  if (total.stars > 0) adjustPlannerChildStars(total.stars);
  setSetting('plannerStarsBackfilled', '1');
}
